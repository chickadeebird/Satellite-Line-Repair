#feature-id BatchLineRepair : ChickadeeScripts > Batch Line Repair
#feature-info This script processes a batch of images for line repair

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/StarDetector.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/ColorSpace.jsh>

#include "LineRepairFunctions.js"

var LineRepairParameters = {
    targetWindow: null,
    previewZoomLevel: "Fit to Preview",
    shapes: [],
    shapeTypes: [], 
    displayLines: true,
    lineWidth: 5,
    detectionThreshold: 0.5,
    rangeThreshold: 0.25,
    searchImagePaths: [],

    save: function () {
        Parameters.set("shapes", JSON.stringify(this.shapes));
        Parameters.set("shapeTypes", JSON.stringify(this.shapeTypes));
        Parameters.set("previewZoomLevel", this.previewZoomLevel);
        Parameters.set("lineWidth", this.lineWidth);
        Parameters.set("detectionThreshold", this.detectionThreshold);
        Parameters.set("rangeThreshold", this.rangeThreshold);
        Parameters.set("searchImagePaths", JSON.stringify(LineRepairParameters.searchImagePaths));

        if (this.targetWindow) {
            Parameters.set("targetWindow", this.targetWindow.mainView.id);
        }
    },
    load: function () {
        if (Parameters.has("shapes")) {
            this.shapes = JSON.parse(Parameters.getString("shapes"));
        }
        if (Parameters.has("shapeTypes")) {
            this.shapeTypes = JSON.parse(Parameters.getString("shapeTypes"));
        }
        if (Parameters.has("previewZoomLevel")) {
            this.previewZoomLevel = Parameters.getString("previewZoomLevel");
        }
        if (Parameters.has("searchImagePaths"))
            LineRepairParameters.searchImagePaths = JSON.parse(Parameters.get("searchImagePaths"));
        if (Parameters.has("targetWindow")) {
            let windowId = Parameters.getString("targetWindow");
            let window = ImageWindow.windowById(windowId);
            if (window && !window.isNull) {
                this.targetWindow = window;
            }
        }
        this.lineWidth = Number(Parameters.getString("lineWidth"));
        this.detectionThreshold = Number(Parameters.getString("detectionThreshold"));
        this.rangeThreshold = Number(Parameters.getString("rangeThreshold"));

    }
};


// Global object to store preprocessed images
var PreprocessedImages = {
   referenceImage: null,
   searchImages: []
};

// Array to store detected anomalies
let anomalyGroups = [];
let anomalyData = [];

function BatchLineRepairDialog() {
   this.__base__ = Dialog;
   this.__base__();

   // Instruction Label
   this.instructionsLabel = new Label(this);
   this.instructionsLabel.text = "Select the images to repair and the detect/repair parameters, then run the Batch Line Repair.";
   
   // Horizontal Sizer for Search TreeBox and Button
   this.searchSizer = new HorizontalSizer;
   this.searchSizer.spacing = 6;

   // TreeBox to display selected search images
   this.treeBox = new TreeBox(this);
   this.treeBox.numberOfColumns = 1;
   this.treeBox.headerVisible = true;
   this.treeBox.setHeaderText(0, "Selected Repair Images");
   this.treeBox.setMinSize(300, 200);
   this.searchSizer.add(this.treeBox, 100);

   // Search Images Selection Button with Icon (Moved next to TreeBox)
   this.searchButton = new PushButton(this);
   this.searchButton.icon = this.scaledResource(":/icons/select-view.png");
   this.searchButton.setScaledFixedSize(20, 20);
   this.searchButton.toolTip = "Select Repair Images";
   this.searchButton.onClick = function() {
      var dlg = new OpenFileDialog;
      dlg.multipleSelections = true;
      if (dlg.execute()) {
          LineRepairParameters.searchImagePaths = dlg.fileNames;
          LineRepairParameters.detectionThreshold = this.detectionThresholdSlider.value / 100;
          LineRepairParameters.rangeThreshold = this.rangeThresholdSlider.value / 100;
          LineRepairParameters.lineWidth = this.lineWidthSlider.value;
         LineRepairParameters.save();
         this.dialog.treeBox.clear();
         dlg.fileNames.forEach(function(name) {
            var node = new TreeBoxNode(this.dialog.treeBox);
            node.setText(0, File.extractName(name));
         }, this);
      }
   }.bind(this);
   this.searchSizer.add(this.searchButton);

    this.detectionThresholdSlider = new NumericControl(this);
    this.detectionThresholdSlider.label.text = "Detection threshold:";
    this.detectionThresholdSlider.setRange(1, 100);
    this.detectionThresholdSlider.setPrecision(1);
    this.detectionThresholdSlider.slider.setRange(1, 100);
    this.detectionThresholdSlider.setValue(LineRepairParameters.detectionThreshold * 100);
    this.detectionThresholdSlider.toolTip = "Set the threshold of the line detector.\nLower numbers means more lines detected,\nbut a greater chance of detecting non-satellite lines.\nSet it to lower if there are multiple lines of varying intensities,\notherwise 50 should work.";
    // this.starSizeSlider.hide(); // Hide initially
    this.detectionThresholdSlider.onValueUpdated = (value) => {
        LineRepairParameters.detectionThreshold = value / 100;
    };

    this.rangeThresholdSlider = new NumericControl(this);
    this.rangeThresholdSlider.label.text = "Range threshold:";
    this.rangeThresholdSlider.setRange(20, 30);
    this.rangeThresholdSlider.setPrecision(1);
    this.rangeThresholdSlider.slider.setRange(20, 30);
    this.rangeThresholdSlider.setValue(LineRepairParameters.rangeThreshold * 100);
    this.rangeThresholdSlider.toolTip = "Set the threshold of the mask range.\nLower numbers means more lines detected, but noise in the initial estimate\nand more time to compute, but a greater chance of\ndetecting non-satellite lines.";
    // this.starSizeSlider.hide(); // Hide initially
    this.rangeThresholdSlider.onValueUpdated = (value) => {
        LineRepairParameters.rangeThreshold = value / 100;
    };

    this.lineWidthSlider = new NumericControl(this);
    this.lineWidthSlider.label.text = "Line width:";
    this.lineWidthSlider.setRange(1, 9);
    this.lineWidthSlider.setPrecision(1);
    this.lineWidthSlider.slider.setRange(1, 9);
    this.lineWidthSlider.setValue(LineRepairParameters.lineWidth);
    this.lineWidthSlider.toolTip = "Set the width of the line to be repaired.\nIt represents the number of iterations of morphological dilations of\nthe initially drawn single pixel width line.\nIt is set at 5 as default.";
    // this.starSizeSlider.hide(); // Hide initially
    this.lineWidthSlider.onValueUpdated = (value) => {
        LineRepairParameters.lineWidth = value;
    };


    // Update this section to include the AutoSTF checkbox in the zoomSizer
    this.rangeThresholdSizer = new HorizontalSizer;
    this.rangeThresholdSizer.spacing = 4;
    this.rangeThresholdSizer.add(this.rangeThresholdSlider); // Add the AutoSTF checkbox to the sizer

    // Update this section to include the AutoSTF checkbox in the zoomSizer
    this.detectionThresholdSizer = new HorizontalSizer;
    this.detectionThresholdSizer.spacing = 4;
    this.detectionThresholdSizer.add(this.detectionThresholdSlider); // Add the AutoSTF checkbox to the sizer

    // Update this section to include the AutoSTF checkbox in the zoomSizer
    this.lineWidthSizer = new HorizontalSizer;
    this.lineWidthSizer.spacing = 4;
    this.lineWidthSizer.add(this.lineWidthSlider);


   // Run Search Button
   this.searchButton = new PushButton(this);
   this.searchButton.text = "Run Batch Line Repair";
   this.searchButton.onClick = function() {
      this.dialog.runRepair();
   }.bind(this);

   // New Instance Button
   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "New Instance";
   this.newInstanceButton.onMousePress = function() {
      LineRepairParameters.save();
      this.newInstance();
   }.bind(this);

   LineRepairParameters.load();
   if (LineRepairParameters.referenceImagePath) {
      var refNode = new TreeBoxNode(this.referenceTreeBox);
      refNode.setText(0, File.extractName(LineRepairParameters.referenceImagePath));
   }

   if (LineRepairParameters.searchImagePaths) {
      LineRepairParameters.searchImagePaths.forEach(function(name) {
         var node = new TreeBoxNode(this.treeBox);
         node.setText(0, File.extractName(name));
      }, this);
   }

   // Preprocessing Progress Label
   this.preprocessingProgressLabel = new Label(this);
   this.preprocessingProgressLabel.text = "Detection progress";

   // Progress Label
   this.progressLabel = new Label(this);
   this.progressLabel.text = "Repairing progress";

   // Final Setup
   this.sizer = new VerticalSizer;
   this.sizer.margin = 8;
   this.sizer.spacing = 6;
   this.sizer.add(this.instructionsLabel);
   // this.sizer.add(this.refSizer);
   this.sizer.add(this.searchSizer);
   this.sizer.spacing = 6;
   // this.sizer.add(this.thresholdLabel);
    this.sizer.add(this.rangeThresholdSizer);
    this.sizer.add(this.detectionThresholdSizer);
    this.sizer.add(this.lineWidthSizer);
   // this.sizer.add(this.preprocessButton);
   this.sizer.add(this.searchButton);
   this.sizer.add(this.preprocessingProgressLabel);
   this.sizer.add(this.progressLabel);
   this.sizer.add(this.newInstanceButton);

   this.windowTitle = "Batch Line Repair V1.0.0 beta";
}
BatchLineRepairDialog.prototype = new Dialog;

// Preprocess images (reference and search images)
BatchLineRepairDialog.prototype.preprocessImages = function() {
   function preprocessImage(window, imagePath) {
      if (!window || window.isNull) {
         console.warningln("Failed to open image.");
         return;
      }

      var processContainer = new ProcessContainer;
      console.writeln("Preprocessing image: " + imagePath);

      window.hide();

      if (window.mainView.image.isColor) {
         var P001 = new BackgroundNeutralization;
         P001.backgroundLow = 0.0000000;
         P001.backgroundHigh = 0.2000000;
         processContainer.add(P001);
      }

      var P002 = new AutomaticBackgroundExtractor;
      P002.polyDegree = 2;
      P002.targetCorrection = AutomaticBackgroundExtractor.prototype.Subtract;
      P002.normalize = true;
P002.discardModel = true;
P002.replaceTarget = true;
      processContainer.add(P002);

      var P003 = new PixelMath;
      P003.expression = "C = -2.8; B = 0.25; c = min(max(0,med($T)+C*1.4826*mdev($T)),1); mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
      P003.useSingleExpression = true;
      P003.symbols = "C,B,c";
      processContainer.add(P003);

      processContainer.executeOn(window.mainView);
   }

   var self = this;

   self.preprocessingProgressLabel.text = "Preprocessing reference image...";
   self.preprocessingProgressLabel.update();

   PreprocessedImages.referenceImage = ImageWindow.open(LineRepairParameters.referenceImagePath)[0];
   preprocessImage(PreprocessedImages.referenceImage, LineRepairParameters.referenceImagePath);

   PreprocessedImages.searchImages = [];

   LineRepairParameters.searchImagePaths.forEach(function(imagePath, index) {
      self.preprocessingProgressLabel.text = "Preprocessing image " + (index + 1) + " of " + LineRepairParameters.searchImagePaths.length;
      self.preprocessingProgressLabel.update();

      var window = ImageWindow.open(imagePath)[0];
      preprocessImage(window, imagePath);
      PreprocessedImages.searchImages.push(window);
   });

   self.preprocessingProgressLabel.text = "Preprocessing complete!";
   self.preprocessingProgressLabel.update();
   console.writeln("Preprocessing completed.");
};

// Preprocess images (reference and search images)
BatchLineRepairDialog.prototype.runRepair = function () {
    var self = this;
    
    PreprocessedImages.searchImages = [];

    LineRepairParameters.searchImagePaths.forEach(function (imagePath, index) {
        self.preprocessingProgressLabel.text = "Detecting lines in image " + (index + 1) + " of " + LineRepairParameters.searchImagePaths.length;
        self.preprocessingProgressLabel.update();

        var window = ImageWindow.open(imagePath)[0];

        if (!window || window.isNull) {
            console.warningln("Failed to open image.");
            return;
        }

        var processContainer = new ProcessContainer;
        printFilenameToConsole(imagePath);
        // console.writeln("Preprocessing image: " + imagePath);
        self.preprocessingProgressLabel.text = "Detecting lines in image " + (index + 1) + " of " + LineRepairParameters.searchImagePaths.length;
        self.preprocessingProgressLabel.update();
        self.progressLabel.text = "Repairing lines in image " + (index + 0) + " of " + LineRepairParameters.searchImagePaths.length;
        self.progressLabel.update();
        applySTF(window);
        let shapes = detectSatelliteLines(window.mainView.image, LineRepairParameters.rangeThreshold, LineRepairParameters.detectionThreshold);
        Console.writeln("Number of lines detected: " + shapes.length);
        self.progressLabel.text = "Repairing lines in image " + (index + 1) + " of " + LineRepairParameters.searchImagePaths.length;
        self.progressLabel.update();
        repairSatelliteLines(window.mainView, shapes, LineRepairParameters.lineWidth);
        window.show();
        PreprocessedImages.searchImages.push(window);
    });

    self.preprocessingProgressLabel.text = "Detection completed";
    self.preprocessingProgressLabel.update();
    self.progressLabel.text = "Repairing completed!";
    self.progressLabel.update();
    console.writeln("Preprocessing completed.");
};


// Main function
function main() {
    console.show();
    
    Console.writeln("Batch Line Repair Loaded...");

   let dialog = new BatchLineRepairDialog();
   dialog.execute();
}

main();
