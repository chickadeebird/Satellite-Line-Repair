// JavaScript source code

function printFilenameToConsole(imagePath) {
    Console.writeln("Repairing image: " + imagePath);
    return true;
}

function makeArray(rows, cols) {
    // let arr = Array(rows).fill().map(() => Array(cols).fill(0));

    let arr = [];

    for (let i = 0; i < rows; i++) {
        arr[i] = new Array(cols);
        for (let j = 0; j < cols; j++) arr[i][j] = 0;
        // arr[i].fill(0);
    }

    return arr;
}

function applySTF(window) {
    if (!window || window.isNull) {
        Console.writeln("Window either not valid or it is Null - returning");
        return false;
    }

    Console.writeln("Applying STF: " + window.mainView.id);

    // window.mainView.beginProcess();
    // window.mainView.image.assign(selectedImage);
    // window.mainView.endProcess();

    var P = new PixelMath;
    P.expression =
        "C = -2.8  ;\n" +
        "B = 0.20  ;\n" +
        "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
        "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
    P.expression1 = "";
    P.expression2 = "";
    P.expression3 = "";
    P.useSingleExpression = true;
    P.symbols = "C,B,c";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = false;
    P.showNewImage = true;
    P.newImageId = "";
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
    P.executeOn(window.mainView);

    return true;
}

function houghTransform(image, numTheta, edgeThreshold, detectionThreshold) {
    Console.writeln("image bitsPerSample: " + image.bitsPerSample + " isReal: " + image.isReal);
    Console.writeln("image width: " + image.width + " height: " + image.height + " maximum: " + image.maximum() + " minimum: " + image.minimum());
    Console.writeln("edgeThreshold: " + edgeThreshold);
    Console.writeln("detectionThreshold: " + detectionThreshold);
    
    // 1. Edge detection (using a simple threshold for demonstration)
    const edges = [];
    for (let y = 0; y < image.height; y++) {
        for (let x = 0; x < image.width; x++) {
            if (image.sample(x, y) > edgeThreshold) {
                edges.push([x, y]);
            }
        }
    }

    Console.writeln("Number of edge pixels found: " + edges.length);

    // if (1 == 1) return true;

    // 2. Create accumulator array
    const maxRho = Math.round(Math.sqrt(image.width * image.width + image.height * image.height));
    // const numTheta = 720;
    const thetaList = [];
    const sinList = [];
    const cosList = [];
    const EPSILON = 0.001;

    for (let theta = -1 * Math.PI / 2; theta < Math.PI / 2 - EPSILON; theta += Math.PI / numTheta) {
        thetaList.push(theta);
        sinList.push(Math.sin(theta));
        cosList.push(Math.cos(theta));
    }

    const maxDistance = Math.round(2 * maxRho + 1);
    Console.writeln("maxDistance: " + maxDistance + " numTheta: " + numTheta);
    const accumulator = makeArray(maxDistance, numTheta);

    Console.writeln("maxRho: " + maxRho + " numTheta: " + numTheta + " accumulator width: " + accumulator[0].length + " accumulator height: " + accumulator.length + " thetaList length: " + thetaList.length);

    let numEdges = edges.length;

    for (let i = 0; i < numEdges; i++) {
        let point = edges[i];
        let x = point[0];
        let y = point[1];
        
        for (let j = 0; j < numTheta; j++) {
            let accumulatorIndex = Math.round(x * cosList[j] + y * sinList[j]) + maxRho;
            accumulator[accumulatorIndex][j] += 1;
        }
    }

    Console.writeln("Accumulator filled");

    let peakThreshold = detectionThreshold;
    
    let neighborhoodSize = 25;
    let peaks = findHoughPeaks(accumulator, peakThreshold, neighborhoodSize);

    let angles = [];
    let distances = [];
    let peaksList = [];

    for (let i = 0; i < peaks.length; i++) {

        let newAngle = thetaList[peaks[i][1]];
        angles.push(newAngle);
        let newDist = peaks[i][0] - maxRho;
        distances.push(newDist);
        peaksList.push([newAngle, newDist]);
        Console.writeln("offset: " + peaks[i][0] + " theta: " + peaks[i][1] + " peak value: " + peaks[i][2] + " converted angle: " + newAngle + " converted offset: " + newDist);
    }

    if (1 == 1) return peaksList;

    if (a.length > 0)
        return (h, angles[a], dists[d]);
    else
        return (h, Array([]), Array([]));

    return lines;
}

function houghToCartesian(rho, theta) {
    const a = Math.cos(theta);
    const b = Math.sin(theta);
    const x0 = a * rho;
    const y0 = b * rho;
    // const x1 = Math.round(x0 + 1000 * (-b));
    // const y1 = Math.round(y0 + 1000 * (a));
    // const x2 = Math.round(x0 - 1000 * (-b));
    // const y2 = Math.round(y0 - 1000 * (a));

    return [x0, y0];
}

function imageIntercepts(rho, theta, imageWidth, imageHeight) {
    // return x0 y0 x1 y1
    if (theta == 0) return [0, rho, imageWidth, rho];
    if (theta == Math.PI / 4) return [rho, 0, rho, imageHeight];

    // look for y intercept, or when x=0
    let yInterceptZero = rho / Math.sin(theta);
    // look for y intercept, when x=Width
    let yInterceptWidth = (rho - (imageWidth - 1) * Math.cos(theta)) / Math.sin(theta);

    // look for x intercept, or when y=0
    let xInterceptZero = rho / Math.cos(theta);
    // look for x intercept, when y=Height
    let xInterceptHeight = (rho - (imageHeight - 1) * Math.sin(theta)) / Math.cos(theta);

    Console.writeln("yInterceptZero: " + yInterceptZero + " yInterceptWidth: " + yInterceptWidth + " xInterceptZero: " + xInterceptZero + " xInterceptHeight: " + xInterceptHeight);

    // does not intercept x in image
    if ((xInterceptZero <= imageWidth - 1) && (xInterceptZero >= 0) && (xInterceptHeight <= imageWidth - 1) && (xInterceptHeight >= 0)) return [xInterceptZero, 0, xInterceptHeight, imageHeight];

    // does not intercept y in image
    if ((yInterceptZero <= imageHeight - 1) && (yInterceptZero >= 0) && (yInterceptWidth <= imageHeight - 1) && (yInterceptWidth >= 0)) return [0, yInterceptZero, imageWidth, yInterceptWidth];

    let x1 = 0;
    let x2 = 0;
    let y1 = 0;
    let y2 = 0;

    if ((yInterceptZero < imageHeight) && (yInterceptZero >= 0) && (xInterceptZero < imageWidth) && (xInterceptZero >= 0)) {
        y1 = yInterceptZero;
        x2 = xInterceptZero;
    }

    if ((yInterceptWidth < imageHeight) && (yInterceptWidth >= 0) && (xInterceptZero < imageWidth) && (xInterceptZero >= 0)) {
        x1 = xInterceptZero;
        x2 = imageWidth - 1;
        y2 = yInterceptWidth;
    }

    if ((yInterceptWidth < imageHeight) && (yInterceptWidth >= 0) && (xInterceptHeight < imageWidth) && (xInterceptHeight >= 0)) {
        x1 = xInterceptHeight;
        x2 = imageWidth - 1;
        y1 = imageHeight - 1;
        y2 = yInterceptWidth;
    }

    if ((yInterceptZero < imageHeight) && (yInterceptZero >= 0) && (xInterceptHeight < imageWidth) && (xInterceptHeight >= 0)) {
        x2 = xInterceptHeight;
        y1 = yInterceptZero;
        y2 = imageHeight - 1;
    }

    return [x1, y1, x2, y2];
}

function findHoughPeaks(houghSpace, threshold=-1, neighborhoodSize=9) {
    /*
    Function Definition: The function takes three parameters: the 2D Hough space matrix, a threshold value, and the size of the neighborhood.
    Initialization: An empty array peaks is initialized to store the peak coordinates.
    Iterating through the Hough space: Nested loops iterate through each cell of the Hough space matrix.
    Threshold Check: The value in the current cell is checked against the threshold.
    Neighborhood Check: If the value is above the threshold, the function checks if the current cell is a local maximum by comparing it with its neighbors.
    Peak Detection: If the current cell is a local maximum, its coordinates and value are pushed into the peaks array.
    Return: The function returns an array of peaks, where each peak is represented as an array of [row, column, value].
    */
    Console.writeln("findHoughPeaks inputs threshold: " + threshold + " neighborhoodSize: " + neighborhoodSize);
    const peaks = [];
    const numRows = houghSpace.length;
    const numCols = houghSpace[0].length;

    let maxInHough = 0;

    for (let x = 0; x < houghSpace[0].length; x++) {
        for (let y = 0; y < houghSpace.length; y++) {
            if (houghSpace[y][x] > maxInHough) maxInHough = houghSpace[y][x];
        }
    }

    if (threshold < 0) {
        threshold = 0.5 * maxInHough;
    }
    else {
        threshold = threshold * maxInHough;
    }


    Console.writeln("findHoughPeaks calculated threshold: " + threshold + " numRows: " + numRows + " numCols: " + numCols);

    for (let row = 0; row < numRows; row++) {
        for (let col = 0; col < numCols; col++) {

            const value = houghSpace[row][col];

            // Check if the value is above the threshold
            if (value > threshold) {

                let isPeak = true;

                // Check neighborhood
                for (let i = row - neighborhoodSize; i <= row + neighborhoodSize; i++) {
                    for (let j = col - neighborhoodSize; j <= col + neighborhoodSize; j++) {

                        if (i >= 0 && i < numRows && j >= 0 && j < numCols) {
                            if (houghSpace[i][j] > value) {
                                isPeak = false;
                                break;
                            }
                        }
                    }
                    if (!isPeak) {
                        break;
                    }
                }

                if (isPeak) {
                    peaks.push([row, col, value]);
                }
            }
        }
    }

    return peaks;
}

function detectSatelliteLines(selectedImagePassed, rangeThreshold, detectionThreshold) {
    console.noteln("Line repair initiated");
    Console.writeln("rangeThreshold: " + rangeThreshold);
    Console.writeln("detectionThreshold: " + detectionThreshold);
    // console.flush();

    // return;

    // Create a new grayscale image with the same dimensions as the original image to be used as a temporary mask image
    let selectedWindow = new ImageWindow(selectedImagePassed.width, selectedImagePassed.height,
        selectedImagePassed.numberOfChannels, // 1 channel for grayscale
        selectedImagePassed.bitsPerSample,
        selectedImagePassed.isReal,
        false
    );

    // Console.writeln("maskWindow bitsPerSample: " + selectedImage.bitsPerSample + " isReal: " + selectedImage.isReal);

    let selectedImageView = selectedWindow.mainView;
    selectedImageView.beginProcess(UndoFlag_NoSwapFile);
    let selectedImage = selectedImageView.image;
    selectedImage.fill(0); // Initialize the mask image with black (0)

    let self = this; // Store reference to 'this'

    // let viewList = [];
    shapes = [];
    shapeTypes = [];
    // Check if the image is a mono image
    if (selectedImagePassed.numberOfChannels > 1) {
        // (new MessageBox("Only for mono images.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
        // selectedImage = selectedImage[0];
        // console.noteln("Using red channel");
        selectedImage.apply(selectedImagePassed);
        selectedImagePassed.getLightness(selectedImage);

        Console.writeln("RGB converted to grayscale for detection");
        // var P = new ConvertToGrayscale;
        // P.executeOn(selectedImageView);
        /*
        extractChannels(parameters.targetWindow.mainView);
        viewList.push(parameters.targetWindow.mainView.id + "_temp_R");
        viewList.push(parameters.targetWindow.mainView.id + "_temp_G");
        viewList.push(parameters.targetWindow.mainView.id + "_temp_B");
        */
    }
    else {
        selectedImage.apply(selectedImagePassed);
        // viewList.push(parameters.targetWindow.mainView.id);
        Console.writeln("Grayscale kept as grayscale for detection");
    }

    Console.writeln("new selectedWindow id: " + selectedImageView.id);

    // Console.writeln("Number of views to process: " + viewList.length);
    /*
    if (1 == 1) {
        selectedWindow.show();
        return;
    }
    */

    let xCenter = 0;
    let yCenter = 0;

    let RGBcorrectionFactors = [0.9, 0.9, 1.0];

    // for (let imagePlane = 0; imagePlane < viewList.length; imagePlane++)
    if (1 == 1)
    // viewList.forEach((selectedImage) =>
    {
        // let selectedImageView = View.viewById(viewList[imagePlane]);
        // let selectedImage = selectedImageView.image;

        // Create a new grayscale image with the same dimensions as the original image to be used as a temporary mask image
        let maskWindow = new ImageWindow(selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels, // 1 channel for grayscale
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            false
        );

        Console.writeln("maskWindow bitsPerSample: " + selectedImage.bitsPerSample + " isReal: " + selectedImage.isReal);

        let maskImageView = maskWindow.mainView;
        maskImageView.beginProcess(UndoFlag_NoSwapFile);
        let maskImage = maskImageView.image;
        // maskImage.fill(0); // Initialize the mask image with black (0)
        maskWindow.show();
        Console.writeln("maskWindow shown: " + maskImageView.id);
        maskImage.apply(selectedImage);
        Console.writeln("selectedImage applied: " + maskImageView.id);

        // Scale shapes according to the full-size image dimensions
        let scaleRatio = this.downsamplingFactor; // Scale factor from the preview to full-size image

        /*
        if (this.previewControl.shapes < 1) {
            (new MessageBox("No donuts selected with a shape.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
            return;
        }
        */

        var PM = new PixelMath;
        PM.expression =
            "C = -2.8  ;\n" +
            "B = 0.20  ;\n" +
            "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
            "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
        PM.expression1 = "";
        PM.expression2 = "";
        PM.expression3 = "";
        PM.useSingleExpression = true;
        PM.symbols = "C,B,c";
        PM.clearImageCacheAndExit = false;
        PM.cacheGeneratedImages = false;
        PM.generateOutput = true;
        PM.singleThreaded = false;
        PM.optimization = true;
        PM.use64BitWorkingImage = false;
        PM.rescale = false;
        PM.rescaleLower = 0;
        PM.rescaleUpper = 1;
        PM.truncate = true;
        PM.truncateLower = 0;
        PM.truncateUpper = 1;
        PM.createNewImage = false;
        PM.showNewImage = true;
        PM.newImageId = "";
        PM.newImageWidth = 0;
        PM.newImageHeight = 0;
        PM.newImageAlpha = false;
        PM.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        PM.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
        PM.executeOn(maskImageView);

        Console.writeln("PixelMath AutoStretch completed: " + maskImageView.id);

        var PABE = new AutomaticBackgroundExtractor;
        PABE.tolerance = 1.000;
        PABE.deviation = 0.800;
        PABE.unbalance = 1.800;
        PABE.minBoxFraction = 0.050;
        PABE.maxBackground = 1.0000;
        PABE.minBackground = 0.0000;
        PABE.useBrightnessLimits = false;
        PABE.polyDegree = 2;
        PABE.boxSize = 5;
        PABE.boxSeparation = 5;
        PABE.modelImageSampleFormat = AutomaticBackgroundExtractor.prototype.f32;
        PABE.abeDownsample = 2.00;
        PABE.writeSampleBoxes = false;
        PABE.justTrySamples = false;
        PABE.targetCorrection = AutomaticBackgroundExtractor.prototype.Subtract;
        PABE.normalize = false;
        PABE.discardModel = true;
        PABE.replaceTarget = false;
        PABE.correctedImageId = "";
        PABE.correctedImageSampleFormat = AutomaticBackgroundExtractor.prototype.SameAsTarget;
        PABE.verboseCoefficients = false;
        PABE.compareModel = false;
        PABE.compareFactor = 10.00;

        PABE.executeOn(maskImageView);

        Console.writeln("ABE completed: " + maskImageView.id);


        var PConv = new Convolution;
        PConv.mode = Convolution.prototype.Library;
        PConv.sigma = 2.00;
        PConv.shape = 2.00;
        PConv.aspectRatio = 1.00;
        PConv.rotationAngle = 0.00;
        PConv.filterSource = "SeparableFilter {\n" +
            "   name { Gaussian (5) }\n" +
            "   row-vector {  0.010000  0.316228  1.000000  0.316228  0.010000 }\n" +
            "   col-vector {  0.010000  0.316228  1.000000  0.316228  0.010000 }\n" +
            "}\n";
        PConv.rescaleHighPass = false;
        PConv.viewId = "";

        PConv.executeOn(maskImageView);

        Console.writeln("Convolution completed: " + maskImageView.id);


        var PRange = new RangeSelection;
        PRange.lowRange = rangeThreshold;  // was 0.3
        PRange.highRange = 1.000000;
        PRange.fuzziness = 0.00; // was 0.55
        PRange.smoothness = 0.00;
        PRange.screening = false;
        PRange.toLightness = true;
        PRange.invert = false;

        PRange.executeOn(maskImageView);

        Console.writeln("Range completed: " + maskImageView.id);

        let rangeView = View.viewById("range_mask");
        let numTheta = 720;
        let edgeThreshold = 0.0;
        let peaksList = houghTransform(rangeView.image, numTheta, edgeThreshold), detectionThreshold;

        let angle_step = Math.PI / (numTheta * 2);
        let d_step = 0.5;

        Console.writeln("angle_step: " + angle_step + " d_step: " + d_step);

        for (let i = 0; i < peaksList.length; i++) {

            let lineAngle = peaksList[i][0];
            let lineOffset = peaksList[i][1];

            Console.writeln("In main lineOffset: " + lineOffset + " lineAngle: " + lineAngle);

            let boxIntercepts = imageIntercepts(lineOffset, lineAngle, maskImage.width, maskImage.height)

            let x1 = boxIntercepts[0];
            let y1 = boxIntercepts[1];
            let x2 = boxIntercepts[2];
            let y2 = boxIntercepts[3];

            shapes.push([[x1, y1], [x2, y2]]);
            shapeTypes.push("Line");





            Console.writeln("In main x1: " + x1 + " y1: " + y1 + " x2: " + x2 + " y2: " + y2);
        }

        
        
        let tempWindow = ImageWindow.windowById(maskWindow.mainView.id + "_ABE");
        if (!tempWindow.isNull) tempWindow.forceClose();
        tempWindow = ImageWindow.windowById("range_mask");
        if (!tempWindow.isNull) tempWindow.forceClose();
        if (!maskWindow.mainView.window.isNull) maskWindow.mainView.window.forceClose();
        if (!selectedWindow.mainView.window.isNull) selectedWindow.mainView.window.forceClose();
        

        
    }

    return shapes;
}


function repairSatelliteLines(selectedImageView, shapes, lineWidth) {
    console.noteln("Mask Creation Started!");
    console.flush();

    // let self = this; // Store reference to 'this'

    // Check if the image is a mono image
    /*
    if (selectedImage.numberOfChannels > 1) {
        (new MessageBox("Cannot create a Mask from a multi-channel image at this time.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
        return;
    }
    */
    let selectedImage = selectedImageView.image;

    // Create a new grayscale image with the same dimensions as the original image
    let maskWindow = new ImageWindow(selectedImage.width, selectedImage.height,
        1, // 1 channel for grayscale
        selectedImage.bitsPerSample,
        selectedImage.isReal,
        false
    );

    let maskImageView = maskWindow.mainView;
    maskImageView.beginProcess(UndoFlag_NoSwapFile);
    let maskImage = maskImageView.image;
    maskImage.fill(0); // Initialize the mask image with black (0)



    // Scale shapes according to the full-size image dimensions
    let scaleRatio = this.downsamplingFactor; // Scale factor from the preview to full-size image
    Console.writeln("scaleRatio: " + scaleRatio);

    // Function to find the minimum and maximum y-coordinates in the polygon
    function findMinMaxY(polygon) {
        let minY = polygon[0][1];
        let maxY = polygon[0][1];
        for (let i = 1; i < polygon.length; i++) {
            if (polygon[i][1] < minY) minY = polygon[i][1];
            if (polygon[i][1] > maxY) maxY = polygon[i][1];
        }
        return { minY: minY, maxY: maxY };
    }

    function drawLine(array, x0, y0, x1, y1, value) {
        // Calculate the slope
        const dx = x1 - x0;
        const dy = y1 - y0;

        // Bresenham's line algorithm
        let x = x0;
        let y = y0;
        const steps = Math.max(Math.abs(dx), Math.abs(dy));
        const xIncrement = dx / steps;
        const yIncrement = dy / steps;

        for (let i = 0; i <= steps; i++) {
            // Round the coordinates to the nearest integer
            const roundedX = Math.round(x);
            const roundedY = Math.round(y);

            // Make sure the coordinates are within the array bounds
            if (roundedX >= 0 && roundedX < array.width && roundedY >= 0 && roundedY < array.height) {
                array.setSample(1, roundedX, roundedY); // array[roundedY][roundedX] = value;
            }

            x += xIncrement;
            y += yIncrement;
        }
    }


    // Function to fill a polygon using the scan-line filling algorithm
    function fillPolygon(image, polygon) {
        let { minY, maxY } = findMinMaxY(polygon);

        let fillValue = 1;

        let x0 = polygon[0][0], y0 = polygon[0][1];
        let x1 = polygon[1][0], y1 = polygon[1][1];

        drawLine(image, x0, y0, x1, y1, fillValue);

        if (1 == 1) return;

        for (let y = minY; y <= maxY; y++) {
            if (y < 0 || y >= image.height) continue; // Skip out-of-bounds y-coordinates
            let intersections = [];
            for (let i = 0; i < polygon.length; i++) {
                let j = (i + 1) % polygon.length;
                let x1 = polygon[i][0], y1 = polygon[i][1];
                let x2 = polygon[j][0], y2 = polygon[j][1];

                if ((y1 <= y && y < y2) || (y2 <= y && y < y1)) {
                    let x = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
                    intersections.push(Math.round(x));
                }
            }
            intersections.sort((a, b) => a - b);

            for (let k = 0; k < intersections.length; k += 2) {
                let xStart = Math.max(intersections[k], 0);
                let xEnd = Math.min(intersections[k + 1], image.width - 1);
                for (let x = xStart; x <= xEnd; x++) {
                    if (self.maskType === "Binary") {
                        image.setSample(1, x, y, 0); // Set the pixel to white (1) for binary mask
                    } else if (self.maskType === "Lightness") {
                        let brightness = selectedImage.sample(x, y, 0); // Get the brightness value
                        image.setSample(brightness, x, y, 0); // Set the pixel to brightness value for lightness mask
                    } else if (self.maskType === "Chrominance") {
                        if (selectedImage.numberOfChannels < 3) {
                            console.warningln("Cannot Create a Chrominance Mask of a Grey Scale Image!!!");
                            return;
                        }
                        let r = selectedImage.sample(x, y, 0);
                        let g = selectedImage.sample(x, y, 1);
                        let b = selectedImage.sample(x, y, 2);
                        let maxChannel = Math.max(r, g, b);
                        let minChannel = Math.min(r, g, b);
                        let chrominance = (maxChannel - minChannel) / maxChannel; // Calculate chrominance value
                        if (isNaN(chrominance)) chrominance = 0;
                        image.setSample(chrominance, x, y, 0); // Set the pixel to chrominance value for chrominance mask
                    } else if (self.maskType === "Color") {
                        let r = selectedImage.sample(x, y, 0);
                        let g = selectedImage.sample(x, y, 1);
                        let b = selectedImage.sample(x, y, 2);
                        let hue = Math.atan2(Math.sqrt(3) * (g - b), 2 * r - g - b) * 180 / Math.PI;
                        if (hue < 0) hue += 360;
                        let { min, max } = getColorRange(self.colorDropdown.itemText(self.colorDropdown.currentItem));
                        let colorValue = (min < max)
                            ? (hue >= min && hue <= max ? 1 : 0)
                            : ((hue >= min || hue <= max) ? 1 : 0);
                        let chrominance = (Math.max(r, g, b) - Math.min(r, g, b)) / Math.max(r, g, b); // Calculate chrominance value
                        sampleValue = colorValue * chrominance; // Scale color value by chrominance
                        if (isNaN(sampleValue)) sampleValue = 0; // Replace NaN with 0
                        image.setSample(sampleValue, x, y, 0); // Scale color value by chrominance
                    }
                }
            }
        }
    }

    scaleRatio = 1;

    // Fill the mask image with the appropriate values inside the user-defined shapes
    shapes.forEach((shape, index) => {
        let scaledShape = shape.map(point => [point[0] * scaleRatio, point[1] * scaleRatio]);
        
        Console.writeln("Filling shape");
        fillPolygon(maskImage, scaledShape);
    });

    Console.writeln("Mask filled");

    var PMorph = new MorphologicalTransformation;
    PMorph.operator = MorphologicalTransformation.prototype.Dilation;
    PMorph.interlacingDistance = 1;
    PMorph.lowThreshold = 0.000000;
    PMorph.highThreshold = 0.000000;
    PMorph.numberOfIterations = lineWidth;
    PMorph.amount = 1.00;
    PMorph.selectionPoint = 0.50;
    PMorph.structureName = "";
    PMorph.structureSize = 3;
    PMorph.structureWayTable = [ // mask
        [[
            0x00, 0x01, 0x00,
            0x01, 0x01, 0x01,
            0x00, 0x01, 0x00
        ]]
    ];

    PMorph.executeOn(maskImageView);

    Console.writeln("Mask dilated");

    /*
    PMorph.structureWayTable = [ // mask
        [[
            0x00, 0x01, 0x00,
            0x01, 0x01, 0x01,
            0x00, 0x01, 0x00
        ]]
    ];
    */

    // Create a new grayscale image with the same dimensions as the original image
    let invertedMaskWindow = new ImageWindow(selectedImage.width, selectedImage.height,
        1, // 1 channel for grayscale
        selectedImage.bitsPerSample,
        selectedImage.isReal,
        false
    );

    let invertedMaskImageView = invertedMaskWindow.mainView;
    invertedMaskImageView.beginProcess(UndoFlag_NoSwapFile);
    let invertedMaskImage = invertedMaskImageView.image;
    invertedMaskImage.fill(1); // Initialize the mask image with black (0)

    Console.writeln("Inverted mask created");

    var P = new PixelMath;
    P.expression = "" + invertedMaskImageView.id + "-" + maskImageView.id + "";
    P.expression1 = "";
    P.expression2 = "";
    P.expression3 = "";
    P.useSingleExpression = true;
    P.symbols = "";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = false;
    P.showNewImage = true;
    P.newImageId = "";
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

    P.executeOn(invertedMaskImageView);

    Console.writeln("Inverted mask inverted");

    // Create a new grayscale image with the same dimensions as the original image
    let MMTWindow = new ImageWindow(selectedImage.width, selectedImage.height,
        selectedImage.numberOfChannels, // 1 channel for grayscale
        selectedImage.bitsPerSample,
        selectedImage.isReal,
        false
    );

    let MMTImageView = MMTWindow.mainView;
    MMTImageView.beginProcess(UndoFlag_NoSwapFile);
    let MMTImage = MMTImageView.image;
    MMTImage.apply(selectedImage); // Initialize the mask image with black (0)

    Console.writeln("MMT image created");

    var PMMT = new MultiscaleMedianTransform;
    PMMT.layers = [ // enabled, biasEnabled, bias, noiseReductionEnabled, noiseReductionThreshold, noiseReductionAmount, noiseReductionAdaptive
        [false, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [false, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [false, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [false, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [false, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [false, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000]
    ];
    PMMT.transform = MultiscaleMedianTransform.prototype.MultiscaleMedianTransform;
    PMMT.medianWaveletThreshold = 5.00;
    PMMT.scaleDelta = 0;
    PMMT.linearMask = false;
    PMMT.linearMaskAmpFactor = 100;
    PMMT.linearMaskSmoothness = 1.00;
    PMMT.linearMaskInverted = true;
    PMMT.linearMaskPreview = false;
    PMMT.lowRange = 0.0000;
    PMMT.highRange = 0.0000;
    PMMT.previewMode = MultiscaleMedianTransform.prototype.Disabled;
    PMMT.previewLayer = 0;
    PMMT.toLuminance = true;
    PMMT.toChrominance = true;
    PMMT.linear = false;


    PMMT.executeOn(MMTImageView);

    Console.writeln("MMT image executed");

    /*
    var PConv = new Convolution;
    PConv.mode = Convolution.prototype.Parametric;
    PConv.sigma = 9.00;
    PConv.shape = 6.00;
    PConv.aspectRatio = 1.00;
    PConv.rotationAngle = 0.00;
    PConv.filterSource = "";
    PConv.rescaleHighPass = false;
    PConv.viewId = "";

    PConv.executeOn(MMTImageView);
    */

    // Create a new grayscale image with the same dimensions as the original image
    /*
    let finalWindow = new ImageWindow(selectedImage.width, selectedImage.height,
        1, // 1 channel for grayscale
        selectedImage.bitsPerSample,
        selectedImage.isReal,
        false
    );

    let finalImageView = finalWindow.mainView;
    finalImageView.beginProcess(UndoFlag_NoSwapFile);
    let finalImage = finalImageView.image;
    finalImage.apply(selectedImage); // Initialize the mask image with black (0)
    */

    // let selectedImageView = parameters.targetWindow.mainView;
    P.expression = "(" + invertedMaskImageView.id + "*" + selectedImageView.id + ") + (" + maskImageView.id + "*" + MMTImageView.id + ")";


    P.executeOn(selectedImageView);

    // PM.expression = "" + maskImageView.id + "";
    // PM.executeOn(selectedImageView);

    // parameters.displayLines = false;
    // this.createAndDisplayTemporaryImage(selectedImageView.image);

    MMTWindow.show();
    maskWindow.show();
    invertedMaskWindow.show();
    // finalWindow.show();




    
    if (!invertedMaskWindow.mainView.window.isNull) invertedMaskWindow.mainView.window.forceClose();
    if (!MMTWindow.mainView.window.isNull) MMTWindow.mainView.window.forceClose();
    if (!maskWindow.mainView.window.isNull) maskWindow.mainView.window.forceClose();
    












    // maskImageView.endProcess();

    // Set mask window ID based on mask type
    /*
    let maskSuffix = "";
    if (this.maskType === "Binary") {
        maskSuffix = "_bin";
    } else if (this.maskType === "Lightness") {
        maskSuffix = "_lght";
    } else if (this.maskType === "Chrominance") {
        maskSuffix = "_chrm";
    } else if (this.maskType === "Color") {
        maskSuffix = "_color";
    }
    */


    // maskImageView.id = parameters.targetWindow.mainView.id + "_Lines_Mask" + maskSuffix;
    // maskWindow.show();

    // Apply convolution to blur the mask image
    /*
    var blurAmount = this.blurAmount_Slider.value;
    if (blurAmount > 0) {
        var P = new Convolution;
        P.mode = Convolution.prototype.Parametric;
        P.sigma = blurAmount;
        P.executeOn(maskImageView);
    } else {
        console.writeln("Skipping convolution as blurAmount is 0.");
        console.flush();
    }
    */

};

