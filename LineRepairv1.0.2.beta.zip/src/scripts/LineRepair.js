
#feature-id LineRepair : ChickadeeScripts > LineRepair
#feature-info This script detects lines from satellites and repairs them.

// Main Script

/******************************************************************************
 *
 * Line Repair
 * Version: V1.0.0
 * Author: Chick Dee
 * Website: https://github.com/chickadeebird
 *
 * This script is designed for detecting lines across an image, representing satellite tracks, and repairs the image
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Chick Dee. ALL RIGHTS RESERVED.
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>

#define TITLE "LineDetection - Satellite Line Detection Script"
#define VERSION "V1.0.2 beta"

let parameters = {
    targetWindow: null,
    previewZoomLevel: "Fit to Preview",
    shapes: [],
    shapeTypes: [], // Store types of shapes
    displayLines: true,
    lineWidth: 5,
    detectionThreshold: 0.5,
    rangeThreshold: 0.25,
    
    save: function() {
        Parameters.set("shapes", JSON.stringify(this.shapes));
        Parameters.set("shapeTypes", JSON.stringify(this.shapeTypes));
        Parameters.set("previewZoomLevel", this.previewZoomLevel);
        Parameters.set("lineWidth", this.lineWidth);
        Parameters.set("detectionThreshold", this.detectionThreshold);
        Parameters.set("rangeThreshold", this.rangeThreshold);
        
        if (this.targetWindow) {
            Parameters.set("targetWindow", this.targetWindow.mainView.id);
        }
    },
    load: function() {
        if (Parameters.has("shapes")) {
            this.shapes = JSON.parse(Parameters.getString("shapes"));
        }
        if (Parameters.has("shapeTypes")) {
            this.shapeTypes = JSON.parse(Parameters.getString("shapeTypes"));
        }
        if (Parameters.has("previewZoomLevel")) {
            this.previewZoomLevel = Parameters.getString("previewZoomLevel");
        }
        if (Parameters.has("targetWindow")) {
            let windowId = Parameters.getString("targetWindow");
            let window = ImageWindow.windowById(windowId);
            if (window && !window.isNull) {
                this.targetWindow = window;
            }
        }
        this.lineWidth = Number(Parameters.getString("lineWidth"));
        this.detectionThreshold = Number(Parameters.getString("detectionThreshold"));
        this.rangeThreshold = Number(Parameters.getString("rangeThreshold"));
        
    }
};

function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);
    this.isDrawing = false; // Flag for detecting drawing
    this.isTransforming = false; // Flag for detecting transforming (rotate + resize)
    this.currentShape = [];
    this.shapes = [];
    this.shapeTypes = []; // Track types of shapes
    this.displayLines = true;
    this.activeShapeIndex = 0; // Initialize activeShapeIndex
    this.scrollPosition = new Point(0, 0); // Ensure scrollPosition is always defined
    this.previousZoomLevel = 1;
    this.shapeType = "Line"; // Default shape type
    this.transformCenter = null; // Center point for transformations
    this.initialDistance = null; // Initial distance for resizing
    this.initialAngle = null; // Initial angle for rotating

    this.brushRadius = 10; // Default brush radius
    this.sprayDensity = 0.5; // Default spray density
    this.viewport.cursor = new Cursor(StdCursor_Cross);

    this.zoomFactor = 1;
    this.minZoomFactor = 0.1; // Set the minimum zoom factor for zooming out
    this.maxZoomFactor = 10;  // Set the maximum zoom factor for zooming in

    this.lineWidth = 5;
    this.detectionThreshold = 0.5;
    this.rangeThreshold = 0.25;

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        if (this.viewport) {
            this.viewport.update();
        }
    };

this.initScrollBars = function(scrollPoint = null) {
    var image = this.getImage();
    if (image == null || image.width <= 0 || image.height <= 0) {
        this.setHorizontalScrollRange(0, 0);
        this.setVerticalScrollRange(0, 0);
        this.scrollPosition = new Point(0, 0);
    } else {
        let zoomFactor = this.zoomFactor;
        this.setHorizontalScrollRange(0, Math.max(0, (image.width * zoomFactor)));
        this.setVerticalScrollRange(0, Math.max(0, (image.height * zoomFactor)));
        if (scrollPoint) {
            this.scrollPosition = scrollPoint;
        } else {
            this.scrollPosition = new Point(
                Math.min(this.scrollPosition.x, (image.width * zoomFactor)),
                Math.min(this.scrollPosition.y, (image.height * zoomFactor))
            );
        }
    }
    if (this.viewport) {
        this.viewport.update();
    }
};



    this.calculateTransformCenter = function(shape) {
        let sumX = 0;
        let sumY = 0;
        shape.forEach(point => {
            sumX += point[0];
            sumY += point[1];
        });
        return [sumX / shape.length, sumY / shape.length];
    };

    this.calculateDistance = function(x1, y1, x2, y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    };

    this.calculateAngle = function(x1, y1, x2, y2) {
        return Math.atan2(y2 - y1, x2 - x1);
    };

    this.transformShape = function(shape, angle, scaleX, scaleY, centerX, centerY) {
        return shape.map(point => {
            let translatedX = point[0] - centerX;
            let translatedY = point[1] - centerY;
            let rotatedX = translatedX * Math.cos(angle) - translatedY * Math.sin(angle);
            let rotatedY = translatedX * Math.sin(angle) + translatedY * Math.cos(angle);
            let resizedX = rotatedX * scaleX;
            let resizedY = rotatedY * scaleY;
            return [resizedX + centerX, resizedY + centerY];
        });
    };

this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent
    let zoomFactor = parent.zoomFactor;
    let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
    let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

    if (modifiers === 1) { // Shift key detection
        parent.startX = adjustedX;
        parent.startY = adjustedY;
        parent.isDrawing = true;
        parent.dragging = false; // Prevent scrolling while drawing

        // Handle different shape types
        if (parent.shapeType === "Ellipse" || parent.shapeType === "Rectangle") {
            parent.currentShape = [[parent.startX, parent.startY], [parent.startX, parent.startY]];
        } else if (parent.shapeType === "SprayCan") {
            parent.currentShape = []; // Initialize currentShape for spray can
        } else if (parent.shapeType === "Brush") {
            parent.currentShape = []; // Initialize currentShape for brush strokes
        }
    } else if (modifiers === 2) { // Ctrl key detection
        
        parent.startX = adjustedX;
        parent.startY = adjustedY;
        parent.isMoving = false;
        parent.dragging = false; // Prevent scrolling while moving

        // Save original shape
        parent.originalShape = [];
        for (let i = 0; i < parent.shapes[parent.activeShapeIndex].length; i++) {
            parent.originalShape.push(parent.shapes[parent.activeShapeIndex][i].slice());
        }
        
    } else if (modifiers === 4) { // Alt key detection
        parent.startX = adjustedX;
        parent.startY = adjustedY;
        parent.isTransforming = true;
        parent.transformCenter = parent.calculateTransformCenter(parent.shapes[parent.activeShapeIndex]);
        parent.initialAngle = parent.calculateAngle(parent.transformCenter[0], parent.transformCenter[1], parent.startX, parent.startY);
        parent.initialDistance = parent.calculateDistance(parent.startX, parent.startY, parent.transformCenter[0], parent.transformCenter[1]);

        // Save original shape
        parent.originalShape = [];
        for (let i = 0; i < parent.shapes[parent.activeShapeIndex].length; i++) {
            parent.originalShape.push(parent.shapes[parent.activeShapeIndex][i].slice());
        }
    } else {
        this.cursor = new Cursor(StdCursor_ClosedHand);
        parent.startX = adjustedX;
        parent.startY = adjustedY;
        parent.dragOrigin.x = x;
        parent.dragOrigin.y = y;
        parent.dragging = true;
    }
};


this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent
    let zoomFactor = parent.zoomFactor;
    let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
    let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

    if (!parent) return;
    if (parent.isDrawing) {
        let endX = adjustedX;
        let endY = adjustedY;
        
        // let centerX = (parent.startX + endX) / 2;
        // let centerY = (parent.startY + endY) / 2;
        let centerX = parent.startX;
        let centerY = parent.startY;

        // let radiusX = Math.abs(endX - parent.startX) / 2;
        // let radiusY = Math.abs(endY - parent.startY) / 2;
        let radiusX = Math.abs(endX - parent.startX);
        let radiusY = Math.abs(endY - parent.startY);

        

        parent.currentShape = [];
        for (let angle = 0; angle < 2 * Math.PI; angle += 0.01) {
                parent.currentShape.push([
                    centerX + radiusX * Math.cos(angle),
                    centerY + radiusY * Math.sin(angle)
                ]);
        }
        parent.currentShape.push(parent.currentShape[0]); // Close the shape
        
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isMoving) {
        let dx = adjustedX - parent.startX;
        let dy = adjustedY - parent.startY;
        parent.shapes[parent.activeShapeIndex] = parent.originalShape.map(point => [point[0] + dx, point[1] + dy]);
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isTransforming) {
        let currentAngle = parent.calculateAngle(parent.transformCenter[0], parent.transformCenter[1], adjustedX, adjustedY);
        let angleDifference = currentAngle - parent.initialAngle;
        let currentDistance = parent.calculateDistance(adjustedX, adjustedY, parent.transformCenter[0], parent.transformCenter[1]);
        let scale = currentDistance / parent.initialDistance;
        parent.shapes[parent.activeShapeIndex] = parent.transformShape(parent.originalShape, angleDifference, scale, scale, parent.transformCenter[0], parent.transformCenter[1]);
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.dragging) {
        let dx = (parent.dragOrigin.x - x) / zoomFactor;
        let dy = (parent.dragOrigin.y - y) / zoomFactor;
        parent.scrollPosition = new Point(parent.scrollPosition.x + dx, parent.scrollPosition.y + dy);
        parent.dragOrigin.x = x;
        parent.dragOrigin.y = y;
        if (parent.viewport) {
            parent.viewport.update();
        }
    }
};


this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent
    let zoomFactor = parent.zoomFactor;
    let adjustedX = (x / zoomFactor) + parent.scrollPosition.x;
    let adjustedY = (y / zoomFactor) + parent.scrollPosition.y;

    if (!parent) return;

    if (parent.isDrawing) {
        parent.isDrawing = false;

        if (parent.shapes.length > 0) {
            // apparently this is the fastest way to empty a list(?)
            Console.writeln("Emptying existing shapes list");
            parent.shapes.length = 0;
            Console.writeln("Shapes list emptied");
        }

        // Finalize the shape and ensure no extraneous points are added
        parent.shapes.push(parent.currentShape.filter(point => !isNaN(point[0]) && !isNaN(point[1])));
        parent.shapeTypes.push(parent.shapeType); // Save the shape type
        parent.currentShape = [];
        parent.activeShapeIndex = parent.shapes.length - 1; // Set the newly drawn shape as the active shape
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isMoving) {
        parent.isMoving = false;
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else if (parent.isTransforming) {
        parent.isTransforming = false;
        if (parent.viewport) {
            parent.viewport.update();
        }
    } else {
        if ((parent.startX == adjustedX) && (parent.startY == adjustedY)) {
            Console.writeln("modifiers: " + modifiers);
            if (modifiers == 2) {
                Console.writeln("Entering modifiers = 2 -> " + modifiers);
                let closestDistance = 100000;
                let closestX1 = 1;
                let closestY1 = 1;
                let closestX2 = 100;
                let closestY2 = 100;

                for (let i = 0; i < parent.shapes.length; i++) {
                    let polygon = parent.shapes[i];
                    let x1 = polygon[0][0], y1 = polygon[0][1];
                    let x2 = polygon[1][0], y2 = polygon[1][1];
                    // let distance = distanceToLine(adjustedX, adjustedY, x1, y1, x2, y2);
                    const A = y2 - y1;
                    const B = x1 - x2;
                    const C = x2 * y1 - x1 * y2;

                    const numerator = Math.abs(A * adjustedX + B * adjustedY + C);
                    const denominator = Math.sqrt(A * A + B * B);

                    const distance = numerator / denominator;
                    Console.writeln("x: " + adjustedX + " y: " + adjustedY + " x1: " + x1 + " y1: " + y1 + " x2: " + x2 + " y2: " + y2 + " distance: " + distance);

                    if (closestDistance > distance) {
                        closestDistance = distance;
                        closestX1 = x1;
                        closestY1 = y1;
                        closestX2 = x2;
                        closestY2 = y2;
                    }
                }

                Console.writeln("closestDistance: " + closestDistance + " closestX1: " + closestX1 + " closestY1: " + closestY1 + " closestX2: " + closestX2 + " closestY2: " + closestY2);

                parent.shapes.length = 0;

                parent.shapes.push([[closestX1, closestY1], [closestX2, closestY2]]);
                parent.shapeTypes.push("Line");

                if (parent.viewport) {
                    parent.viewport.update();
                }

                Console.writeln("viewport updated");
            }
            else {
                if (parameters.displayLines) {
                    parameters.displayLines = false;
                    // Console.writeln("Setting displayLines to false");

                } else {
                    parameters.displayLines = true;
                    // Console.writeln("Setting displayLines to true");
                }

                if (parent.viewport) {
                    parent.viewport.update();
                }
            }
        }

        this.cursor = new Cursor(StdCursor_Cross);
        parent.dragging = false;
    }
};


this.viewport.onMouseWheel = function(x, y, delta, buttons, modifiers) {
    var parent = this.parent; // Store reference to parent

    if (!parent.displayImage) {
        console.error("No display image set.");
        return;
    }

    let oldZoomFactor = parent.zoomFactor;

    // Calculate the old scroll position percentage
    let maxHorizontalScroll = (parent.displayImage.width * oldZoomFactor) - parent.viewport.width;
    let maxVerticalScroll = (parent.displayImage.height * oldZoomFactor) - parent.viewport.height;
    let oldScrollPercentageX = parent.scrollPosition.x / maxHorizontalScroll;
    let oldScrollPercentageY = parent.scrollPosition.y / maxVerticalScroll;

    // Update the zoom factor based on the wheel delta
    if (delta > 0) {
        parent.zoomFactor = Math.min(parent.zoomFactor * 1.25, parent.maxZoomFactor);
    } else if (delta < 0) {
        parent.zoomFactor = Math.max(parent.zoomFactor * 0.8, parent.minZoomFactor);
    }
    let newZoomFactor = parent.zoomFactor;

    // Reinitialize scrollbars to reflect the new zoom level
    parent.initScrollBars();

    // Calculate the new scroll position using the old scroll percentage
    maxHorizontalScroll = (parent.displayImage.width * newZoomFactor) - parent.viewport.width;
    maxVerticalScroll = (parent.displayImage.height * newZoomFactor) - parent.viewport.height;
    let newScrollPositionX = oldScrollPercentageX * maxHorizontalScroll;
    let newScrollPositionY = oldScrollPercentageY * maxVerticalScroll;

    // Ensure the new scroll position stays within valid bounds
    newScrollPositionX = Math.max(0, Math.min(newScrollPositionX, maxHorizontalScroll));
    newScrollPositionY = Math.max(0, Math.min(newScrollPositionY, maxVerticalScroll));

    // Update the scroll position to keep the same relative position
    parent.scrollPosition = new Point(newScrollPositionX, newScrollPositionY);

    parent.viewport.update();
};


// Updated onPaint
this.viewport.onPaint = function(x0, y0, x1, y1) {
    
    var g = new Graphics(this);
    var result = this.parent.getImage();
    let zoomFactor = this.parent.zoomFactor;

    if (result == null) {
        g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
    } else {
        // Apply the scaling transformation
        g.scaleTransformation(zoomFactor);

        // Translate the image to account for scrolling
        g.translateTransformation(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y);

        // Draw the image
        g.drawBitmap(0, 0, result.render());

        if (!parameters.displayLines) {
            // Console.writeln("Returning because displayLines is false");
            return;
        }
        else {
            // Console.writeln("Continuing because displayLines is true");
        }

        // Draw the user-defined shapes if they exist
        this.parent.shapes.forEach((shape, index) => {
            g.pen = new Pen(index === this.parent.activeShapeIndex ? 0xff00ff00 : 0xffff0000);

            
            
            for (let i = 0; i < shape.length - 1; i++) {
                if (Number.isFinite(shape[i][0]) && Number.isFinite(shape[i][1]) && Number.isFinite(shape[i + 1][0]) && Number.isFinite(shape[i + 1][1])) {
                    g.drawLine(shape[i][0], shape[i][1],
                        shape[i + 1][0], shape[i + 1][1]);
                }
            }
        });
        
        // Draw the current shape if it exists
        if (this.parent.currentShape.length > 0) {
            g.pen = new Pen(0xff00ff00);
            
            for (let i = 0; i < this.parent.currentShape.length - 1; i++) {
                if (Number.isFinite(this.parent.currentShape[i][0]) && Number.isFinite(this.parent.currentShape[i][1]) && Number.isFinite(this.parent.currentShape[i + 1][0]) && Number.isFinite(this.parent.currentShape[i + 1][1])) {
                    g.drawLine(this.parent.currentShape[i][0], this.parent.currentShape[i][1],
                        this.parent.currentShape[i + 1][0], this.parent.currentShape[i + 1][1]);
                }
            }
        }
    }

    g.end();
    gc();
};





    this.setFocus = function() {
        this.viewport.onKeyPress = (keyCode, modifiers) => {
            if (keyCode === 0x20) { // Spacebar key
                this.activeShapeIndex = (this.activeShapeIndex + 1) % this.shapes.length;
                this.viewport.update();
            }
        };
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;


// Function to scale all shapes when zoom changes
ScrollControl.prototype.scaleShapes = function(newZoomLevel) {
    try {
        let scaleRatio = this.previousZoomLevel / newZoomLevel;
        this.shapes = this.shapes.map((shape, index) => {
            if (this.shapeTypes[index] === "SprayCan") {
                return this.scaleSprayCanPoints(shape, scaleRatio);
            } else if (this.shapeTypes[index] === "Brush") {
                return this.scaleBrushPoints(shape, scaleRatio);
            } else {
                return shape.map(point => [
                    Math.round(point[0] * scaleRatio),
                    Math.round(point[1] * scaleRatio)
                ]);
            }
        });
        this.previousZoomLevel = newZoomLevel;
        if (this.viewport) {
            this.viewport.update();
        }
    } catch (error) {
        // Suppress any warnings or errors
        console.warningln("Error during shape scaling: " + error);
    }
};

// Ensure this function is called whenever the zoom level changes
HaloBGoneDialog.prototype.updateZoomLevel = function(newZoomLevel) {
    if (this.previewControl) {
        this.previewControl.scaleShapes(newZoomLevel);
    }
};


function HaloBGoneDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.maskType = 'Binary';

    this.title_Lbl = new Label(this);
    this.title_Lbl.frameStyle = FrameStyle_Box;
    this.title_Lbl.margin = 6;
    this.title_Lbl.useRichText = true;
    this.title_Lbl.text = "<b>Satellite Line Detection Script " + VERSION + "</b>";
    this.title_Lbl.textAlignment = TextAlign_Center;

    this.instructions_Lbl = new TextBox(this);
    this.instructions_Lbl.readOnly = true;
    this.instructions_Lbl.frameStyle = FrameStyle_Box;
    this.instructions_Lbl.text = "Instructions:\n\nSelect the image to be repaired from \nthe Select Image selector.\n\nUse the mouse wheel in the image view window \nto zoom in and out.\n\nThe Detect button will detect long lines in the\nimage and display the detected lines in green.\n\nOnce the lines are detected, mouse button click\nin the image area will toggle the detected lines\n\nThe repair button will repair the image with a\nline of the selected line width.\n\nThe undo button will undo any repairs made, \nbut the detected lines will be kept, just not \ndisplayed unless toggled on with a mouse click.";
    this.instructions_Lbl.setScaledMinWidth(450); // Set a fixed width for the instructions
    this.instructions_Lbl.setScaledMinHeight(320); // Set a fixed width for the instructions

    let currentWindowName = ImageWindow.activeWindow.mainView.id;
    this.imageLabel = new Label(this);
    this.imageLabel.text = "Select Image:";
    this.imageLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.windowSelector_Cb = new ComboBox(this);
    this.windowSelector_Cb.toolTip = "Select the window you want to use.";
    for (var i = 0; i < ImageWindow.windows.length; i++) {
        this.windowSelector_Cb.addItem(ImageWindow.windows[i].mainView.id);
        if (ImageWindow.windows[i].mainView.id == currentWindowName) {
            this.windowSelector_Cb.currentItem = i;
            let window = ImageWindow.windowById(currentWindowName);
            if (window && !window.isNull) {
                parameters.targetWindow = window;
            }
        }
    }

    this.windowSelector_Cb.onItemSelected = (index) => {
        if (index >= 0) {
            let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(index));
            if (window && !window.isNull) {
                parameters.targetWindow = window;
                let selectedImage = window.mainView.image;
                if (selectedImage) {
                    console.writeln("Displaying the selected image in the preview.");
                    var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();
                    // Set the previous zoom level to the initial downsampling factor
                    this.previousZoomLevel = this.downsamplingFactor;
                } else {
                    console.error("Selected image is undefined.");
                }
            } else {
                console.writeln("No valid window selected for preview!");
                this.previewControl.visible = false;
                this.zoomSizer.visible = false;
                this.adjustToContents();
            }
        }
    };

    // 
    this.imageSelectionSizer = new HorizontalSizer;
    this.imageSelectionSizer.spacing = 4;
    this.imageSelectionSizer.add(this.imageLabel); // Add the label to the sizer
    this.imageSelectionSizer.add(this.windowSelector_Cb, 1);

    this.shapeType = "Ellipse"; // Default shape type
    

  
    // Add the AutoSTF checkbox
    this.autoSTF_Cb = new CheckBox(this);
    this.autoSTF_Cb.text = "AutoSTF";
    this.autoSTF_Cb.checked = true; // Default to unchecked
    this.autoSTF_Cb.onCheck = () => {
        if (parameters.targetWindow) {
            var selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                let tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.viewport.update();
            }
        }
    };

    this.zoomLabel = new Label(this);
    this.zoomLabel.text = "Preview Zoom Level: ";
    this.zoomLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.zoomLevelComboBox = new ComboBox(this);
    this.zoomLevelComboBox.addItem("1:1");
    // this.zoomLevelComboBox.addItem("1:2");
    // this.zoomLevelComboBox.addItem("1:4");
    // this.zoomLevelComboBox.addItem("1:8");
    // this.zoomLevelComboBox.addItem("Fit to Preview");
    this.zoomLevelComboBox.currentItem = 0;

    // Add a variable to store the previous zoom level
    this.previousZoomLevel = this.zoomLevelComboBox.currentItem;

    this.zoomLevelComboBox.onItemSelected = (index) => {
        if (parameters.targetWindow) {
            var selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                console.writeln("Adjusting preview for image with ID: " + parameters.targetWindow.mainView.id);
                let tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.viewport.update();

                // Scale shapes according to the new zoom level
                let newZoomLevel = this.downsamplingFactor;
                this.scaleShapes(newZoomLevel);
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for preview!");
        }
    };

    this.resetButton = new ToolButton(this);
    this.resetButton.icon = this.scaledResource(":/icons/execute.png"); // Updated to use the red lightning bolt icon
    this.resetButton.toolTip = "Reset selections";
    this.resetButton.onMousePress = () => {
        this.previewControl.shapes = [];
        this.previewControl.viewport.update();
    };

    this.undoButton = new ToolButton(this);
    this.undoButton.icon = this.scaledResource(":/icons/reload.png"); // Updated to use the grey icon for undo
    this.undoButton.toolTip = "Undo last shape";
    this.undoButton.onMousePress = () => {
        if (this.previewControl.shapes.length > 0) {
            // Remove the active shape
            this.previewControl.shapes.splice(this.previewControl.activeShapeIndex, 1);

            // Adjust activeShapeIndex
            if (this.previewControl.shapes.length === 0) {
                this.previewControl.activeShapeIndex = 0; // Reset to 0 if no shapes are left
            } else {
                this.previewControl.activeShapeIndex = this.previewControl.activeShapeIndex % this.previewControl.shapes.length;
            }

            this.previewControl.viewport.update();
        }
    };

    this.starSizeSlider = new NumericControl(this);
    this.starSizeSlider.label.text = "Line width:";
    this.starSizeSlider.setRange(1, 9);
    this.starSizeSlider.setPrecision(1);
    this.starSizeSlider.slider.setRange(1, 9);
    this.starSizeSlider.setValue(parameters.lineWidth);
    this.starSizeSlider.toolTip = "Set the width of the line to be repaired.\nIt represents the number of iterations of morphological dilations of\nthe initially drawn single pixel width line.\nIt is set at 5 as default.";
    // this.starSizeSlider.hide(); // Hide initially
    this.starSizeSlider.onValueUpdated = (value) => {
        parameters.lineWidth = value;
    };

    this.detectionThresholdSlider = new NumericControl(this);
    this.detectionThresholdSlider.label.text = "Detection threshold:";
    this.detectionThresholdSlider.setRange(1, 100);
    this.detectionThresholdSlider.setPrecision(1);
    this.detectionThresholdSlider.slider.setRange(1, 100);
    this.detectionThresholdSlider.setValue(parameters.detectionThreshold * 100);
    this.detectionThresholdSlider.toolTip = "Set the threshold of the line detector.\nLower numbers means more lines detected,\nbut a greater chance of detecting non-satellite lines.\nSet it to lower if there are multiple lines of varying intensities,\notherwise 50 should work.";
    // this.starSizeSlider.hide(); // Hide initially
    this.detectionThresholdSlider.onValueUpdated = (value) => {
        parameters.detectionThreshold = value / 100;
    };

    this.rangeThresholdSlider = new NumericControl(this);
    this.rangeThresholdSlider.label.text = "Range threshold:";
    this.rangeThresholdSlider.setRange(20, 30);
    this.rangeThresholdSlider.setPrecision(1);
    this.rangeThresholdSlider.slider.setRange(20, 30);
    this.rangeThresholdSlider.setValue(parameters.rangeThreshold * 100);
    this.rangeThresholdSlider.toolTip = "Set the threshold of the mask range.\nLower numbers means more lines detected, but noise in the initial estimate\nand more time to compute, but a greater chance of\ndetecting non-satellite lines.";
    // this.starSizeSlider.hide(); // Hide initially
    this.rangeThresholdSlider.onValueUpdated = (value) => {
        parameters.rangeThreshold = value / 100;
    };

    
    // Update this section to include the AutoSTF checkbox in the zoomSizer
    this.rangeThresholdSizer = new HorizontalSizer;
    this.rangeThresholdSizer.spacing = 4;
    this.rangeThresholdSizer.add(this.rangeThresholdSlider); // Add the AutoSTF checkbox to the sizer

    // Update this section to include the AutoSTF checkbox in the zoomSizer
    this.detectionThresholdSizer = new HorizontalSizer;
    this.detectionThresholdSizer.spacing = 4;
    this.detectionThresholdSizer.add(this.detectionThresholdSlider); // Add the AutoSTF checkbox to the sizer

    // Update this section to include the AutoSTF checkbox in the zoomSizer
    this.starSizeSizer = new HorizontalSizer;
    this.starSizeSizer.spacing = 4;
    this.starSizeSizer.add(this.starSizeSlider);


    // Update this section to include the AutoSTF checkbox in the zoomSizer
    this.zoomSizer = new HorizontalSizer;
    this.zoomSizer.spacing = 4;
    this.zoomSizer.add(this.autoSTF_Cb); // Add the AutoSTF checkbox to the sizer
    this.zoomSizer.add(this.zoomLabel);
    this.zoomSizer.add(this.zoomLevelComboBox);
    this.zoomSizer.add(this.undoButton); // Add the undo button next to the zoom control
    this.zoomSizer.add(this.resetButton); // Add the reset button next to the zoom control

    // Define the label for the authorship information
    this.authorship_Lbl = new Label(this);
    this.authorship_Lbl.frameStyle = FrameStyle_Box;
    this.authorship_Lbl.margin = 6;
    this.authorship_Lbl.useRichText = true;
    this.authorship_Lbl.text = "Written by Chick Dee<br>Website: <a href=\"https://github.com/chickadeebird\">github.com/chickadeebird</a>";
    this.authorship_Lbl.textAlignment = TextAlign_Center;

    this.newInstance_Btn = new ToolButton(this);
    this.newInstance_Btn.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstance_Btn.setScaledFixedSize(24, 24);
    this.newInstance_Btn.toolTip = "Create new instance with the current parameters.";
    this.newInstance_Btn.onMousePress = () => {
        parameters.save();
        this.newInstance();
    };

    this.execute_Btn = new PushButton(this);
    this.execute_Btn.text = "Detect";
    this.execute_Btn.toolTip = "Detect lines in the image";
    // Correcting the execute button's onClick function to use the generateMaskImage method
    this.execute_Btn.onClick = () => {
        console.writeln("Executing the script with the selected parameters.");
        if (parameters.targetWindow) {
            let selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                this.repairDustDonut(selectedImage);
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for mask generation!");
        }
    };

    this.repairButton = new PushButton(this);
    this.repairButton.text = "Repair";
    this.repairButton.toolTip = "Repair lines in the image";
    // Correcting the execute button's onClick function to use the generateMaskImage method
    this.repairButton.onClick = () => {
        console.writeln("Executing the script with the selected parameters.");
        if (parameters.targetWindow) {
            let selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                this.generateMaskImage(selectedImage);
            } else {
                console.error("Selected image is undefined.");
            }
        } else {
            console.writeln("No image selected for mask generation!");
        }
    };

    this.undoRepairButton = new PushButton(this);
    this.undoRepairButton.text = "Undo";
    this.undoRepairButton.toolTip = "Undo the last repair";
    this.undoRepairButton.icon = ":/icons/undo.png";
    this.undoRepairButton.onClick = () => {
        if (parameters.targetWindow && !parameters.targetWindow.isNull) {
            parameters.targetWindow.undo();
            let selectedImage = parameters.targetWindow.mainView.image;
            if (selectedImage) {
                console.writeln("Displaying the selected image in the preview.");
                var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                this.previewControl.displayImage = tmpImage;
                this.previewControl.initScrollBars();
                this.previewControl.viewport.update();
                // Set the previous zoom level to the initial downsampling factor
                this.previousZoomLevel = this.downsamplingFactor;
            } else {
                console.error("Undone image is undefined.");
            }
        } else {
            console.writeln("No valid window selected for undo!");
            // this.previewControl.visible = false;
            // this.zoomSizer.visible = false;
            // this.adjustToContents();
        }
    };


    this.buttonSizerHorizontal = new HorizontalSizer;
    this.buttonSizerHorizontal.spacing = 6;
    this.buttonSizerHorizontal.add(this.newInstance_Btn);
    this.buttonSizerHorizontal.addStretch(); 
    this.buttonSizerHorizontal.add(this.execute_Btn);
    this.buttonSizerHorizontal.add(this.repairButton);
    this.buttonSizerHorizontal.add(this.undoRepairButton);

    this.previewControl = new ScrollControl(this);
    this.previewControl.setMinWidth(640);
    this.previewControl.setMinHeight(450);

    // Create the label with the desired text
this.zoomInstructionLabel = new Label(this);
this.zoomInstructionLabel.text = "Use the Mouse Wheel to Zoom In and Out";
this.zoomInstructionLabel.textAlignment = TextAlign_Center;

// Create a vertical sizer to hold the label and the previewControl
this.previewSizer = new VerticalSizer;
this.previewSizer.spacing = 4;
this.previewSizer.add(this.zoomInstructionLabel);
this.previewSizer.add(this.previewControl, 1);

    this.mainSizer = new HorizontalSizer;
    this.mainSizer.spacing = 4;

    // Define a spacer control with a fixed width
    this.leftSideSpacer = new Control(this);
    this.leftSideSpacer.setFixedWidth(5); // Adjust the width as needed

    // Insert the spacer control at the beginning of the mainSizer
    this.mainSizer.insert(0, this.leftSideSpacer);
    this.mainSizer.addSpacing(0); // Add some spacing after the spacer

    this.leftSizer = new VerticalSizer;
    this.leftSizer.spacing = 6;
    this.leftSizer.add(this.title_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.instructions_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.imageSelectionSizer); // Add the image selection sizer
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.rangeThresholdSizer); // Add the shape type sizer
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.detectionThresholdSizer); // Add the shape type sizer
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.starSizeSizer); // Add the shape type sizer
    this.leftSizer.addSpacing(10);
    
    // this.leftSizer.add(this.rangeThresholdSizer); // Add the blur amount slider
    this.leftSizer.addSpacing(10);
    // this.leftSizer.add(this.maskTypeSizer);
    // this.leftSizer.add(this.colorMaskSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.zoomSizer);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.authorship_Lbl);
    this.leftSizer.addSpacing(10);
    this.leftSizer.add(this.buttonSizerHorizontal);

// Create a control to fix the width of the left panel
this.leftPanel = new Control(this);
this.leftPanel.sizer = this.leftSizer;
this.leftPanel.setFixedWidth(320); // Adjust this value as needed

// Add the leftSizer and the previewSizer to the mainSizer
this.mainSizer.add(this.leftPanel);
this.mainSizer.add(this.previewSizer);

    this.sizer = this.mainSizer;

    this.windowTitle = "Satellite Line Detection Script (Line Detection)";
    this.adjustToContents();

    // Add key event listener
    this.onKeyDown = function(keyCode, modifiers) {
        if (keyCode === 0x20) { // Spacebar key
            if (this.previewControl.shapes.length > 0) {
                this.previewControl.activeShapeIndex = (this.previewControl.activeShapeIndex + 1) % this.previewControl.shapes.length;
                this.previewControl.viewport.update();
            }
        }
    }.bind(this);

    // Ensure the initial display setup calls the correct function
    this.onShow = () => {
        if (this.windowSelector_Cb.currentItem >= 0) { // Adjust for "Select Image:" item
            let window = ImageWindow.windowById(this.windowSelector_Cb.itemText(this.windowSelector_Cb.currentItem));
            if (window && !window.isNull) {
                let selectedImage = window.mainView.image;
                if (selectedImage) {
                    console.writeln("Displaying the initial image in the preview.");
                    var tmpImage = this.createAndDisplayTemporaryImage(selectedImage);
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();

                    // Set the previous zoom level to the initial downsampling factor
                    this.previousZoomLevel = this.downsamplingFactor;
                }
            }
        } else {
            console.noteln("No image selected for preview.");
            this.previewControl.visible = false;
            this.zoomSizer.visible = false;
            this.adjustToContents(); // Adjust the dialog size to fit the initial content
        }

        this.previewControl.setFocus(); // Set focus to handle key events
    };

    
    // Function to scale shapes according to the new zoom level
    this.scaleShapes = function(newZoomLevel) {
        try {
            let scaleRatio = this.previousZoomLevel / newZoomLevel;
            this.previewControl.shapes = this.previewControl.shapes.map(shape => shape.map(point => [point[0] * scaleRatio, point[1] * scaleRatio]));
            this.previousZoomLevel = newZoomLevel;
            if (this.previewControl.viewport) {
                this.previewControl.viewport.update();
            }
        } catch (error) {
            // Suppress any warnings or errors
        }
    };

    // Function to create, resize, and display a temporary image
    this.createAndDisplayTemporaryImage = function(selectedImage) {
        let window = new ImageWindow(selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor
        );

        window.mainView.beginProcess();
        window.mainView.image.assign(selectedImage);
        window.mainView.endProcess();

        if (this.autoSTF_Cb.checked) {
            var P = new PixelMath;
            P.expression =
                "C = -2.8  ;\n" +
                "B = 0.20  ;\n" +
                "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
                "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
            P.expression1 = "";
            P.expression2 = "";
            P.expression3 = "";
            P.useSingleExpression = true;
            P.symbols = "C,B,c";
            P.clearImageCacheAndExit = false;
            P.cacheGeneratedImages = false;
            P.generateOutput = true;
            P.singleThreaded = false;
            P.optimization = true;
            P.use64BitWorkingImage = false;
            P.rescale = false;
            P.rescaleLower = 0;
            P.rescaleUpper = 1;
            P.truncate = true;
            P.truncateLower = 0;
            P.truncateUpper = 1;
            P.createNewImage = false;
            P.showNewImage = true;
            P.newImageId = "";
            P.newImageWidth = 0;
            P.newImageHeight = 0;
            P.newImageAlpha = false;
            P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
            P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
            P.executeOn(window.mainView);
        }

        var P = new IntegerResample;
        switch (this.zoomLevelComboBox.currentItem) {
            case 0: // 1:1
                P.zoomFactor = -1;
                this.downsamplingFactor = 1;
                break;
            case 1: // 1:2
                P.zoomFactor = -2;
                this.downsamplingFactor = 2;
                break;
            case 2: // 1:4
                P.zoomFactor = -4;
                this.downsamplingFactor = 4;
                break;
            case 3: // 1:8
                P.zoomFactor = -8;
                this.downsamplingFactor = 8;
                break;
            case 4: // Fit to Preview
                const previewWidth = this.previewControl.width;
                const widthScale = Math.floor(selectedImage.width / previewWidth);
                P.zoomFactor = -Math.max(widthScale, 1);
                this.downsamplingFactor = Math.max(widthScale, 1);
                break;
            default:
                P.zoomFactor = -2; // Default to 1:2 if nothing is selected
                this.downsamplingFactor = 2;
                break;
        }

        P.executeOn(window.mainView);

        let resizedImage = new Image(window.mainView.image);

        if (resizedImage.width > 0 && resizedImage.height > 0) {
            this.previewControl.displayImage = resizedImage;
            this.previewControl.doUpdateImage(resizedImage);
            this.previewControl.initScrollBars();
        } else {
            console.error("Resized image has invalid dimensions.");
        }

        window.forceClose();

        return resizedImage;
    };
}
HaloBGoneDialog.prototype = new Dialog;

// Update mask generation logic to handle the "Color" mask type
function getColorRange(color) {
    switch (color) {
        case "Red":
            return { min: 330, max: 40 }; // Adjusted to be narrower in the orange region
        case "Yellow":
            return { min: 40, max: 85 }; // Adjusted to be narrower in the red region
        case "Green":
            return { min: 85, max: 160 }; // Kept as is
        case "Cyan":
            return { min: 160, max: 200 }; // Kept as is
        case "Blue":
            return { min: 200, max: 270 }; // Kept as is
        case "Magenta":
            return { min: 270, max: 330 }; // Extended into the purple region
        default:
            return { min: 0, max: 0 }; // Default to no range
    }
}

function sortRing(values, coordinates) {
    if (values.length !== coordinates.length) {
        throw new Error("Values and coordinates arrays must be the same length.");
    }

    // Find the centroid of the ring
    let centroidX = 0, centroidY = 0;
    for (let coord of coordinates) {
        centroidX += coord[0];
        centroidY += coord[1];
    }
    centroidX /= coordinates.length;
    centroidY /= coordinates.length;

    // Calculate angles for each point relative to the centroid
    const angles = coordinates.map(coord => {
        const x = coord[0] - centroidX;
        const y = coord[1] - centroidY;
        return Math.atan2(y, x);
    });

    // Sort the values and coordinates based on angles
    const sortedIndices = angles.map((_, i) => i)
        .sort((a, b) => angles[a] - angles[b]);

    const sortedValues = sortedIndices.map(i => values[i]);
    const sortedCoordinates = sortedIndices.map(i => coordinates[i]);

    return [ sortedValues, sortedCoordinates ];
}

function slidingMedian(nums, k) {
    const result = [];

    for (let i = 0; i < nums.length - k + 1; i++) {
        const window = nums.slice(i, i + k);
        window.sort((a, b) => a - b);

        const mid = Math.floor(window.length / 2);
        if (window.length % 2 === 0) {
            result.push((window[mid - 1] + window[mid]) / 2);
        } else {
            result.push(window[mid]);
        }
    }

    return result;
}

function slidingMedianWraparound(arr, k) {
    if (k <= 0 || arr.length < k) {
        return [];
    }

    const result = [];

    for (let i = 0; i < arr.length; i++) {
        const window = [];

        for (let j = 0; j < k; j++) {
            const index = (i + j) % arr.length;
            window.push(arr[index]);
        }

        window.sort((a, b) => a - b);
        const midpointDivisor = 2;
        const mid = Math.floor(k / midpointDivisor);

        if (k % 2 === 0) {
            result.push((window[mid - 1] + window[mid]) / 2);
        } else {
            result.push(window[mid]);
        }
    }

    return result;
}

function extractChannels(view) {
    var P = new ChannelExtraction;
    P.colorSpace = ChannelExtraction.prototype.RGB;
    P.channels = [ // enabled, id
        [true, view.id + "_temp_R"],
        [true, view.id + "_temp_G"],
        [true, view.id + "_temp_B"]
    ];
    P.sampleFormat = ChannelExtraction.prototype.SameAsSource;
    //P.inheritAstrometricSolution =

    P.executeOn(view);
}

function combine(viewR, viewG, viewB, resultView) {
    var P = new ChannelCombination;
    P.colorSpace = ChannelCombination.prototype.RGB;
    P.channels = [ // enabled, id
        [true, viewR.id],
        [true, viewG.id],
        [true, viewB.id]
    ];
    P.executeOn(resultView);
}

function closeView(view) {
    if (view !== undefined && view != null && view.window != null) {
        try {
            Console.writeln("closing view: " + view.id);
            view.window.forceClose();
        }
        catch (error) {
            Console.writeln("could not close view..." + error);
        }
    }
}

function medianOfList(arr) {
    // Sort the array in ascending order
    arr.sort((a, b) => a - b);

    const length = arr.length;

    // If the array has an odd length
    if (length % 2 === 1) {
        return arr[Math.floor(length / 2)];
    } else {
        // If the array has an even length
        const mid1 = arr[length / 2 - 1];
        const mid2 = arr[length / 2];
        return (mid1 + mid2) / 2;
    }
}

function calculateMeanAndStdDev(arr) {
    // Calculate the mean
    const n = arr.length;
    const mean = arr.reduce((sum, value) => sum + value, 0) / n;

    // Calculate the variance
    const variance = arr.reduce((sum, value) => sum + Math.pow(value - mean, 2), 0) / n;

    // Calculate the standard deviation
    const stdDev = Math.sqrt(variance);

    return [ mean, stdDev ];
}

function makeArray(rows, cols) {
    // let arr = Array(rows).fill().map(() => Array(cols).fill(0));
    
    let arr = [];

    for (let i = 0; i < rows; i++) {
        arr[i] = new Array(cols);
        for (let j = 0; j < cols; j++) arr[i][j] = 0;
        // arr[i].fill(0);
    }
    
    return arr;
}

/*
function houghLinePeaks(image, min_xdistance=10, min_ydistance=9, num_peaks=100, threshold=-1) {
    
    Parameters
    ----------
        image : (M, N) ndarray
        Input image.
        min_xdistance : int
        Minimum distance separating features in the x dimension.
        min_ydistance : int
        Minimum distance separating features in the y dimension.
        threshold : float
        Minimum intensity of peaks.Default is`0.5 * max(image)`.
        num_peaks : int
        Maximum number of peaks.When the number of peaks exceeds`num_peaks`,
        return `num_peaks` coordinates based on peak intensity.

        Returns
    -------
        intensity, xcoords, ycoords : tuple of array
        Peak intensity values, x and y indices.
    
    Console.writeln("houghLinePeaks inputs min_xdistance: " + min_xdistance + " min_ydistance: " + min_ydistance + " num_peaks: " + num_peaks);

    // let minAngle = 10;
    // let minDistance = 9;

    // image, min_xdistance = 1, min_ydistance = 1, threshold = None, num_peaks = np.inf

    if (min_xdistance < image[0].length) min_xdistance = image[0].length;

    if (threshold < 0) threshold = 0.5 * Math.max(image);


}
*/
function findHoughPeaks(houghSpace, threshold=-1, neighborhoodSize=9) {
    /*
    Function Definition: The function takes three parameters: the 2D Hough space matrix, a threshold value, and the size of the neighborhood.
    Initialization: An empty array peaks is initialized to store the peak coordinates.
    Iterating through the Hough space: Nested loops iterate through each cell of the Hough space matrix.
    Threshold Check: The value in the current cell is checked against the threshold.
    Neighborhood Check: If the value is above the threshold, the function checks if the current cell is a local maximum by comparing it with its neighbors.
    Peak Detection: If the current cell is a local maximum, its coordinates and value are pushed into the peaks array.
    Return: The function returns an array of peaks, where each peak is represented as an array of [row, column, value].
    */
    Console.writeln("findHoughPeaks inputs threshold: " + threshold + " neighborhoodSize: " + neighborhoodSize);
    const peaks = [];
    const numRows = houghSpace.length;
    const numCols = houghSpace[0].length;

    let maxInHough = 0;

    for (let x = 0; x < houghSpace[0].length; x++) {
        for (let y = 0; y < houghSpace.length; y++) {
            if (houghSpace[y][x] > maxInHough) maxInHough = houghSpace[y][x];
        }
    }

    if (threshold < 0) {
        threshold = 0.5 * maxInHough;
    }
    else {
        threshold = threshold * maxInHough;
    }


    Console.writeln("findHoughPeaks calculated threshold: " + threshold + " numRows: " + numRows + " numCols: " + numCols);

    for (let row = 0; row < numRows; row++) {
        for (let col = 0; col < numCols; col++) {

            const value = houghSpace[row][col];

            // Check if the value is above the threshold
            if (value > threshold) {

                let isPeak = true;

                // Check neighborhood
                for (let i = row - neighborhoodSize; i <= row + neighborhoodSize; i++) {
                    for (let j = col - neighborhoodSize; j <= col + neighborhoodSize; j++) {

                        if (i >= 0 && i < numRows && j >= 0 && j < numCols) {
                            if (houghSpace[i][j] > value) {
                                isPeak = false;
                                break;
                            }
                        }
                    }
                    if (!isPeak) {
                        break;
                    }
                }

                if (isPeak) {
                    peaks.push([row, col, value]);
                }
            }
        }
    }

    return peaks;
}

function houghTransform(image, numTheta, edgeThreshold) {
    Console.writeln("image bitsPerSample: " + image.bitsPerSample + " isReal: " + image.isReal);
    Console.writeln("image width: " + image.width + " height: " + image.height + " maximum: " + image.maximum() + " minimum: " + image.minimum());
    Console.writeln("edgeThreshold: " + edgeThreshold);
    // if (1 == 1) return true;

    // 1. Edge detection (using a simple threshold for demonstration)
    const edges = [];
    for (let y = 0; y < image.height; y++) {
        for (let x = 0; x < image.width; x++) {
            if (image.sample(x, y) > edgeThreshold) {
                edges.push([x, y]);
            }
        }
    }

    Console.writeln("Number of edge pixels found: " + edges.length);

    // if (1 == 1) return true;

    // 2. Create accumulator array
    const maxRho = Math.round(Math.sqrt(image.width * image.width + image.height * image.height));
    // const numTheta = 720;
    const thetaList = [];
    const sinList = [];
    const cosList = [];
    const EPSILON = 0.001;

    for (let theta = -1 * Math.PI/2; theta < Math.PI/2 - EPSILON; theta += Math.PI / numTheta) {
        thetaList.push(theta);
        sinList.push(Math.sin(theta));
        cosList.push(Math.cos(theta));
    }

    // const accumulator = Array.from({ length: numTheta }, () => Array(2 * maxRho + 1).fill(0));
    const maxDistance = Math.round(2 * maxRho + 1);
    Console.writeln("maxDistance: " + maxDistance + " numTheta: " + numTheta);
    const accumulator = makeArray(maxDistance, numTheta);

    Console.writeln("maxRho: " + maxRho + " numTheta: " + numTheta + " accumulator width: " + accumulator[0].length + " accumulator height: " + accumulator.length + " thetaList length: " + thetaList.length);

    // if (1 == 1) return true;

    let numEdges = edges.length;

    for (let i = 0; i < numEdges; i++) {
        let point = edges[i];
        let x = point[0];
        let y = point[1];
        /*
        if (i < 10) {
            Console.writeln("x: " + x + " y: " + y);
        }
        */
        for (let j = 0; j < numTheta; j++) {
            let accumulatorIndex = Math.round(x * cosList[j] + y * sinList[j]) + maxRho;
            accumulator[accumulatorIndex][j] += 1;
        }
    }

    Console.writeln("Accumulator filled");

    // if (1 == 1) return accumulator;

    let peakThreshold = parameters.detectionThreshold;
    /*
    let h, a, d = houghLinePeaks(hspace, angle, dists, numPeaks, peakThreshold);
    let h = houghPeakReturn.h;
    let a = houghPeakReturn.a;
    let d = houghPeakReturn.d;
    */
    let neighborhoodSize = 25;
    let peaks = findHoughPeaks(accumulator, peakThreshold, neighborhoodSize);

    let angles = [];
    let distances = [];
    let peaksList = [];

    for (let i = 0; i < peaks.length; i++) {
        
        let newAngle = thetaList[peaks[i][1]];
        angles.push(newAngle);
        let newDist = peaks[i][0] - maxRho;
        distances.push(newDist);
        peaksList.push([newAngle, newDist]);
        Console.writeln("offset: " + peaks[i][0] + " theta: " + peaks[i][1] + " peak value: " + peaks[i][2] + " converted angle: " + newAngle + " converted offset: " + newDist);
    }

    

    if (1 == 1) return peaksList;

    if (a.length > 0)
        return (h, angles[a], dists[d]);
    else
        return (h, Array([]), Array([]));

        /*
    from..feature.peak import _prominent_peaks

    min_angle = min(min_angle, hspace.shape[1])
    h, a, d = _prominent_peaks(
        hspace,
        min_xdistance = min_angle,
        min_ydistance = min_distance,
        threshold = threshold,
        num_peaks = num_peaks,
    )
    if a.size > 0:
        return (h, angles[a], dists[d])
    else:
    return (h, np.array([]), np.array([]))

    */

/*
    for i in range(nidxs):
        x = x_idxs[i]
    y = y_idxs[i]
    for j in range(nthetas):
        accum_idx = round((ctheta[j] * x + stheta[j] * y)) + offset
    accum[accum_idx, j] += 1
    */
    // 3. Vote for lines
    /*
    for (let [x, y] of edges) {
        for (let theta = 0; theta < numTheta; theta++) {
            const rho = Math.round(x * Math.cos(theta * Math.PI / 180) + y * Math.sin(theta * Math.PI / 180));
            if (rho >= 0 && rho <= maxRho) {
                accumulator[theta][rho]++;
            }
        }
    }

    // 4. Find peaks in accumulator (simplified)
    const lines = [];
    const threshold = 10; // Adjust as needed
    for (let theta = 0; theta < numTheta; theta++) {
        for (let rho = 0; rho <= maxRho; rho++) {
            if (accumulator[theta][rho] > threshold) {
                lines.push({ theta: theta, rho: rho });
            }
        }
    }
    */
    return lines;
}

function houghToCartesian(rho, theta) {
    const a = Math.cos(theta);
    const b = Math.sin(theta);
    const x0 = a * rho;
    const y0 = b * rho;
    // const x1 = Math.round(x0 + 1000 * (-b));
    // const y1 = Math.round(y0 + 1000 * (a));
    // const x2 = Math.round(x0 - 1000 * (-b));
    // const y2 = Math.round(y0 - 1000 * (a));

    return [ x0, y0];
}

function imageIntercepts(rho, theta, imageWidth, imageHeight) {
    // return x0 y0 x1 y1
    if (theta == 0) return [0, rho, imageWidth, rho];
    if (theta == Math.PI / 4) return [rho, 0, rho, imageHeight];

    // look for y intercept, or when x=0
    let yInterceptZero = rho / Math.sin(theta);
    // look for y intercept, when x=Width
    let yInterceptWidth = (rho - (imageWidth - 1) * Math.cos(theta)) / Math.sin(theta);

    // look for x intercept, or when y=0
    let xInterceptZero = rho / Math.cos(theta);
    // look for x intercept, when y=Height
    let xInterceptHeight = (rho - (imageHeight - 1) * Math.sin(theta)) / Math.cos(theta);

    Console.writeln("yInterceptZero: " + yInterceptZero + " yInterceptWidth: " + yInterceptWidth + " xInterceptZero: " + xInterceptZero + " xInterceptHeight: " + xInterceptHeight);

    // does not intercept x in image
    if ((xInterceptZero <= imageWidth - 1) && (xInterceptZero >= 0) && (xInterceptHeight <= imageWidth - 1) && (xInterceptHeight >= 0)) return [xInterceptZero, 0, xInterceptHeight, imageHeight];

    // does not intercept y in image
    if ((yInterceptZero <= imageHeight - 1) && (yInterceptZero >= 0) && (yInterceptWidth <= imageHeight - 1) && (yInterceptWidth >= 0)) return [0, yInterceptZero, imageWidth, yInterceptWidth];

    let x1 = 0;
    let x2 = 0;
    let y1 = 0;
    let y2 = 0;

    if ((yInterceptZero < imageHeight) && (yInterceptZero >= 0) && (xInterceptZero < imageWidth) && (xInterceptZero >= 0)) {
        y1 = yInterceptZero;
        x2 = xInterceptZero;
    }

    if ((yInterceptWidth < imageHeight) && (yInterceptWidth >= 0) && (xInterceptZero < imageWidth) && (xInterceptZero >= 0)) {
        x1 = xInterceptZero;
        x2 = imageWidth - 1;
        y2 = yInterceptWidth;
    }

    if ((yInterceptWidth < imageHeight) && (yInterceptWidth >= 0) && (xInterceptHeight < imageWidth) && (xInterceptHeight >= 0)) {
        x1 = xInterceptHeight;
        x2 = imageWidth - 1;
        y1 = imageHeight - 1;
        y2 = yInterceptWidth;
    }

    if ((yInterceptZero < imageHeight) && (yInterceptZero >= 0) && (xInterceptHeight < imageWidth) && (xInterceptHeight >= 0)) {
        x2 = xInterceptHeight;
        y1 = yInterceptZero;
        y2 = imageHeight - 1;
    }

    return [x1, y1, x2, y2];
}


HaloBGoneDialog.prototype.repairDustDonut = function (selectedImagePassed) {
    /*
    const arr = [1, 3, 5, 7, 9, 2, 4, 6];
    const k = 3;

    const medians = slidingMedianWraparound(arr, k);
    Console.writeln("slidingMedianWraparound: " + medians);

    return;
    */
    console.noteln("Line repair initiated");
    console.flush();

    // Create a new grayscale image with the same dimensions as the original image to be used as a temporary mask image
    let selectedWindow = new ImageWindow(selectedImagePassed.width, selectedImagePassed.height,
        selectedImagePassed.numberOfChannels, // 1 channel for grayscale
        selectedImagePassed.bitsPerSample,
        selectedImagePassed.isReal,
        false
    );

    // Console.writeln("maskWindow bitsPerSample: " + selectedImage.bitsPerSample + " isReal: " + selectedImage.isReal);

    let selectedImageView = selectedWindow.mainView;
    selectedImageView.beginProcess(UndoFlag_NoSwapFile);
    let selectedImage = selectedImageView.image;
    selectedImage.fill(0); // Initialize the mask image with black (0)

    let self = this; // Store reference to 'this'

    // let viewList = [];
    this.previewControl.shapes = [];
    this.previewControl.shapeTypes = [];
    // Check if the image is a mono image
    if (selectedImagePassed.numberOfChannels > 1) {
        // (new MessageBox("Only for mono images.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
        // selectedImage = selectedImage[0];
        // console.noteln("Using red channel");
        selectedImage.apply(selectedImagePassed);
        selectedImagePassed.getLightness(selectedImage);

        Console.writeln("RGB converted to grayscale for detection");
        // var P = new ConvertToGrayscale;
        // P.executeOn(selectedImageView);
        /*
        extractChannels(parameters.targetWindow.mainView);
        viewList.push(parameters.targetWindow.mainView.id + "_temp_R");
        viewList.push(parameters.targetWindow.mainView.id + "_temp_G");
        viewList.push(parameters.targetWindow.mainView.id + "_temp_B");
        */
    }
    else {
        selectedImage.apply(selectedImagePassed);
        // viewList.push(parameters.targetWindow.mainView.id);
        Console.writeln("Grayscale kept as grayscale for detection");
    }

    Console.writeln("new selectedWindow id: " + selectedImageView.id);

    // Console.writeln("Number of views to process: " + viewList.length);
    /*
    if (1 == 1) {
        selectedWindow.show();
        return;
    }
    */

    let xCenter = 0;
    let yCenter = 0;

    let RGBcorrectionFactors = [0.9, 0.9, 1.0];

    // for (let imagePlane = 0; imagePlane < viewList.length; imagePlane++)
    if (1 == 1)
        // viewList.forEach((selectedImage) =>
    {
        // let selectedImageView = View.viewById(viewList[imagePlane]);
        // let selectedImage = selectedImageView.image;

        // Create a new grayscale image with the same dimensions as the original image to be used as a temporary mask image
        let maskWindow = new ImageWindow(selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels, // 1 channel for grayscale
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            false
        );

        Console.writeln("maskWindow bitsPerSample: " + selectedImage.bitsPerSample + " isReal: " + selectedImage.isReal);

        let maskImageView = maskWindow.mainView;
        maskImageView.beginProcess(UndoFlag_NoSwapFile);
        let maskImage = maskImageView.image;
        // maskImage.fill(0); // Initialize the mask image with black (0)
        maskWindow.show();
        Console.writeln("maskWindow shown: " + maskImageView.id);
        maskImage.apply(selectedImage);
        Console.writeln("selectedImage applied: " + maskImageView.id);

        // Scale shapes according to the full-size image dimensions
        let scaleRatio = this.downsamplingFactor; // Scale factor from the preview to full-size image

        /*
        if (this.previewControl.shapes < 1) {
            (new MessageBox("No donuts selected with a shape.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
            return;
        }
        */

        var PM = new PixelMath;
        PM.expression =
            "C = -2.8  ;\n" +
            "B = 0.20  ;\n" +
            "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
            "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
        PM.expression1 = "";
        PM.expression2 = "";
        PM.expression3 = "";
        PM.useSingleExpression = true;
        PM.symbols = "C,B,c";
        PM.clearImageCacheAndExit = false;
        PM.cacheGeneratedImages = false;
        PM.generateOutput = true;
        PM.singleThreaded = false;
        PM.optimization = true;
        PM.use64BitWorkingImage = false;
        PM.rescale = false;
        PM.rescaleLower = 0;
        PM.rescaleUpper = 1;
        PM.truncate = true;
        PM.truncateLower = 0;
        PM.truncateUpper = 1;
        PM.createNewImage = false;
        PM.showNewImage = true;
        PM.newImageId = "";
        PM.newImageWidth = 0;
        PM.newImageHeight = 0;
        PM.newImageAlpha = false;
        PM.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        PM.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
        PM.executeOn(maskImageView);

        Console.writeln("PixelMath AutoStretch completed: " + maskImageView.id);

        var PABE = new AutomaticBackgroundExtractor;
        PABE.tolerance = 1.000;
        PABE.deviation = 0.800;
        PABE.unbalance = 1.800;
        PABE.minBoxFraction = 0.050;
        PABE.maxBackground = 1.0000;
        PABE.minBackground = 0.0000;
        PABE.useBrightnessLimits = false;
        PABE.polyDegree = 2;
        PABE.boxSize = 5;
        PABE.boxSeparation = 5;
        PABE.modelImageSampleFormat = AutomaticBackgroundExtractor.prototype.f32;
        PABE.abeDownsample = 2.00;
        PABE.writeSampleBoxes = false;
        PABE.justTrySamples = false;
        PABE.targetCorrection = AutomaticBackgroundExtractor.prototype.Subtract;
        PABE.normalize = false;
        PABE.discardModel = true;
        PABE.replaceTarget = false;
        PABE.correctedImageId = "";
        PABE.correctedImageSampleFormat = AutomaticBackgroundExtractor.prototype.SameAsTarget;
        PABE.verboseCoefficients = false;
        PABE.compareModel = false;
        PABE.compareFactor = 10.00;

        PABE.executeOn(maskImageView);

        Console.writeln("ABE completed: " + maskImageView.id);


        var PConv = new Convolution;
        PConv.mode = Convolution.prototype.Library;
        PConv.sigma = 2.00;
        PConv.shape = 2.00;
        PConv.aspectRatio = 1.00;
        PConv.rotationAngle = 0.00;
        PConv.filterSource = "SeparableFilter {\n" +
            "   name { Gaussian (5) }\n" +
            "   row-vector {  0.010000  0.316228  1.000000  0.316228  0.010000 }\n" +
            "   col-vector {  0.010000  0.316228  1.000000  0.316228  0.010000 }\n" +
            "}\n";
        PConv.rescaleHighPass = false;
        PConv.viewId = "";

        PConv.executeOn(maskImageView);

        Console.writeln("Convolution completed: " + maskImageView.id);


        var PRange = new RangeSelection;
        PRange.lowRange = parameters.rangeThreshold;  // was 0.3
        PRange.highRange = 1.000000;
        PRange.fuzziness = 0.00; // was 0.55
        PRange.smoothness = 0.00;
        PRange.screening = false;
        PRange.toLightness = true;
        PRange.invert = false;

        PRange.executeOn(maskImageView);

        Console.writeln("Range completed: " + maskImageView.id);

        let rangeView = View.viewById("range_mask");
        let numTheta = 720;
        let edgeThreshold = 0.0;
        let peaksList = houghTransform(rangeView.image, numTheta, edgeThreshold);

        let angle_step = Math.PI / (numTheta * 2);
        let d_step = 0.5;

        Console.writeln("angle_step: " + angle_step + " d_step: " + d_step);

        for (let i = 0; i < peaksList.length; i++) {

            let lineAngle = peaksList[i][0];
            let lineOffset = peaksList[i][1];
            
            Console.writeln("In main lineOffset: " + lineOffset + " lineAngle: " + lineAngle);

            let boxIntercepts = imageIntercepts(lineOffset, lineAngle, maskImage.width, maskImage.height)

            let x1 = boxIntercepts[0];
            let y1 = boxIntercepts[1];
            let x2 = boxIntercepts[2];
            let y2 = boxIntercepts[3];

            this.previewControl.shapes.push([[x1, y1], [x2, y2]]);
            this.previewControl.shapeTypes.push("Line");


            

            
            Console.writeln("In main x1: " + x1 + " y1: " + y1 + " x2: " + x2 + " y2: " + y2);
        }

        this.previewControl.displayLines = true;
        
        this.previewControl.viewport.update();

        maskImageView.endProcess();

        let tempWindow = ImageWindow.windowById(maskWindow.mainView.id + "_ABE");
        if (!tempWindow.isNull) tempWindow.forceClose();
        tempWindow = ImageWindow.windowById("range_mask");
        if (!tempWindow.isNull) tempWindow.forceClose();
        if (!maskWindow.mainView.window.isNull) maskWindow.mainView.window.forceClose();
        if (!selectedWindow.mainView.window.isNull) selectedWindow.mainView.window.forceClose();


        /*
        Console.writeln("houghReturn width: " + houghReturn[0].length + " height: " + houghReturn.length);

        // Create a new grayscale image with the same dimensions as the original image
        let houghWindow = new ImageWindow(houghReturn[0].length, houghReturn.length,
            1, // 1 channel for grayscale
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            false
        );

        let houghImageView = houghWindow.mainView;
        houghImageView.beginProcess(UndoFlag_NoSwapFile);
        let houghImage = houghImageView.image;
        houghImage.fill(0); // Initialize the mask image with black (0)

        Console.writeln("houghReturn[x, y]: " + houghReturn[0][0]);

        let maxInHough = 0;

        for (let x = 0; x < houghReturn[0].length; x++) {
            for (let y = 0; y < houghReturn.length; y++) {
                if (houghReturn[y][x] > maxInHough) maxInHough = houghReturn[y][x];
            }
        }

        Console.writeln("maxInHough: " + maxInHough);

        for (let x = 0; x < houghReturn[0].length; x++) {
            for (let y = 0; y < houghReturn.length; y++) {
                // Console.writeln("x: " + x + " y: " + y);
                // if (houghReturn[y][x] > maxInHough) maxInHough = houghReturn[y][x];
                let houghValue = houghReturn[y][x] / maxInHough;
                // Console.writeln("houghValue: " + houghValue);
                houghImage.setSample(houghValue, x, y);
                // Console.writeln("houghValue set");
            }
        }

        houghWindow.show();
        */
        
        // PM.expression = "" + maskImageView.id + "";
        // PM.executeOn(selectedImageView);
        /*
        if (selectedImagePassed.numberOfChannels < 2) {
            // this.createAndDisplayTemporaryImage(selectedImageView.image);
            this.createAndDisplayTemporaryImage(selectedImage);
            this.previewControl.shapes = [];
        }

        // this.previewControl.doUpdateImage(maskImage);

        if (!maskWindow.mainView.window.isNull) maskWindow.mainView.window.forceClose();
        if (!ringMaskWindow.mainView.window.isNull) ringMaskWindow.mainView.window.forceClose();
        if (!medianMaskWindow.mainView.window.isNull) medianMaskWindow.mainView.window.forceClose();
        if (!residualStarsWindow.mainView.window.isNull) residualStarsWindow.mainView.window.forceClose();
        if (!newFillWindow.mainView.window.isNull) newFillWindow.mainView.window.forceClose();

        this.haloWidthSlider.setValue(Math.floor(avgRadius / 2));
        parameters.mostRecentHaloRadius = Math.floor(avgRadius / 2);

        Console.writeln("maskWindows cleaned up");
        */
    }
    /*
    if (selectedImagePassed.numberOfChannels > 1) {
        // (new MessageBox("Only for mono images.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
        // selectedImage = selectedImage[0];
        // console.noteln("Using red channel");
        let viewR = View.viewById(parameters.targetWindow.mainView.id + "_temp_R");
        let viewG = View.viewById(parameters.targetWindow.mainView.id + "_temp_G");
        let viewB = View.viewById(parameters.targetWindow.mainView.id + "_temp_B");
        combine(viewR, viewG, viewB, parameters.targetWindow.mainView);
        this.createAndDisplayTemporaryImage(parameters.targetWindow.mainView.image);
        this.previewControl.shapes = [];
        viewR.window.forceClose();
        viewG.window.forceClose();
        viewB.window.forceClose();
    }
    */
    
}


HaloBGoneDialog.prototype.generateMaskImage = function(selectedImage) {
    console.noteln("Mask Creation Started!");
    console.flush();

    let self = this; // Store reference to 'this'

    // Check if the image is a mono image
    /*
    if (selectedImage.numberOfChannels > 1) {
        (new MessageBox("Cannot create a Mask from a multi-channel image at this time.", TITLE, StdIcon_Error, StdButton_Ok)).execute();
        return;
    }
    */
    // Create a new grayscale image with the same dimensions as the original image
    let maskWindow = new ImageWindow(selectedImage.width, selectedImage.height,
        1, // 1 channel for grayscale
        selectedImage.bitsPerSample,
        selectedImage.isReal,
        false
    );

    let maskImageView = maskWindow.mainView;
    maskImageView.beginProcess(UndoFlag_NoSwapFile);
    let maskImage = maskImageView.image;
    maskImage.fill(0); // Initialize the mask image with black (0)



    // Scale shapes according to the full-size image dimensions
    let scaleRatio = this.downsamplingFactor; // Scale factor from the preview to full-size image
    Console.writeln("scaleRatio: " + scaleRatio);

    // Function to find the minimum and maximum y-coordinates in the polygon
    function findMinMaxY(polygon) {
        let minY = polygon[0][1];
        let maxY = polygon[0][1];
        for (let i = 1; i < polygon.length; i++) {
            if (polygon[i][1] < minY) minY = polygon[i][1];
            if (polygon[i][1] > maxY) maxY = polygon[i][1];
        }
        return { minY: minY, maxY: maxY };
    }

    function drawLine(array, x0, y0, x1, y1, value) {
        // Calculate the slope
        const dx = x1 - x0;
        const dy = y1 - y0;

        // Bresenham's line algorithm
        let x = x0;
        let y = y0;
        const steps = Math.max(Math.abs(dx), Math.abs(dy));
        const xIncrement = dx / steps;
        const yIncrement = dy / steps;

        for (let i = 0; i <= steps; i++) {
            // Round the coordinates to the nearest integer
            const roundedX = Math.round(x);
            const roundedY = Math.round(y);

            // Make sure the coordinates are within the array bounds
            if (roundedX >= 0 && roundedX < array.width && roundedY >= 0 && roundedY < array.height) {
                array.setSample(1, roundedX, roundedY); // array[roundedY][roundedX] = value;
            }

            x += xIncrement;
            y += yIncrement;
        }
    }


    // Function to fill a polygon using the scan-line filling algorithm
    function fillPolygon(image, polygon) {
        let { minY, maxY } = findMinMaxY(polygon);

        let fillValue = 1;

        let x0 = polygon[0][0], y0 = polygon[0][1];
        let x1 = polygon[1][0], y1 = polygon[1][1];

        drawLine(image, x0, y0, x1, y1, fillValue);

        if (1 == 1) return;

        for (let y = minY; y <= maxY; y++) {
            if (y < 0 || y >= image.height) continue; // Skip out-of-bounds y-coordinates
            let intersections = [];
            for (let i = 0; i < polygon.length; i++) {
                let j = (i + 1) % polygon.length;
                let x1 = polygon[i][0], y1 = polygon[i][1];
                let x2 = polygon[j][0], y2 = polygon[j][1];

                if ((y1 <= y && y < y2) || (y2 <= y && y < y1)) {
                    let x = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
                    intersections.push(Math.round(x));
                }
            }
            intersections.sort((a, b) => a - b);

            for (let k = 0; k < intersections.length; k += 2) {
                let xStart = Math.max(intersections[k], 0);
                let xEnd = Math.min(intersections[k + 1], image.width - 1);
                for (let x = xStart; x <= xEnd; x++) {
                    if (self.maskType === "Binary") {
                        image.setSample(1, x, y, 0); // Set the pixel to white (1) for binary mask
                    } else if (self.maskType === "Lightness") {
                        let brightness = selectedImage.sample(x, y, 0); // Get the brightness value
                        image.setSample(brightness, x, y, 0); // Set the pixel to brightness value for lightness mask
                    } else if (self.maskType === "Chrominance") {
                        if (selectedImage.numberOfChannels < 3) {
                            console.warningln("Cannot Create a Chrominance Mask of a Grey Scale Image!!!");
                            return;
                        }
                        let r = selectedImage.sample(x, y, 0);
                        let g = selectedImage.sample(x, y, 1);
                        let b = selectedImage.sample(x, y, 2);
                        let maxChannel = Math.max(r, g, b);
                        let minChannel = Math.min(r, g, b);
                        let chrominance = (maxChannel - minChannel) / maxChannel; // Calculate chrominance value
                        if (isNaN(chrominance)) chrominance = 0;
                        image.setSample(chrominance, x, y, 0); // Set the pixel to chrominance value for chrominance mask
                    } else if (self.maskType === "Color") {
                        let r = selectedImage.sample(x, y, 0);
                        let g = selectedImage.sample(x, y, 1);
                        let b = selectedImage.sample(x, y, 2);
                        let hue = Math.atan2(Math.sqrt(3) * (g - b), 2 * r - g - b) * 180 / Math.PI;
                        if (hue < 0) hue += 360;
                        let { min, max } = getColorRange(self.colorDropdown.itemText(self.colorDropdown.currentItem));
                        let colorValue = (min < max)
                            ? (hue >= min && hue <= max ? 1 : 0)
                            : ((hue >= min || hue <= max) ? 1 : 0);
                        let chrominance = (Math.max(r, g, b) - Math.min(r, g, b)) / Math.max(r, g, b); // Calculate chrominance value
                           sampleValue = colorValue * chrominance; // Scale color value by chrominance
                           if (isNaN(sampleValue)) sampleValue = 0; // Replace NaN with 0
                        image.setSample(sampleValue, x, y, 0); // Scale color value by chrominance
                    }
                }
            }
        }
    }

    // Fill the mask image with the appropriate values inside the user-defined shapes
    this.previewControl.shapes.forEach((shape, index) => {
        let scaledShape = shape.map(point => [point[0] * scaleRatio, point[1] * scaleRatio]);
        if (self.previewControl.shapeTypes[index] === "Brush") {
            drawBrushStrokes(maskImage, shape, self.previewControl.brushRadius, scaleRatio);
        } else if (self.previewControl.shapeTypes[index] === "SprayCan") {
            let scaledSprayCanPoints = scaleSprayCanPoints(shape, scaleRatio);
            drawSprayCanPoints(maskImage, scaledSprayCanPoints);
        } else {
            Console.writeln("Filling shape");
            fillPolygon(maskImage, scaledShape);
        }
    });

    Console.writeln("Mask filled");

    var PMorph = new MorphologicalTransformation;
    PMorph.operator = MorphologicalTransformation.prototype.Dilation;
    PMorph.interlacingDistance = 1;
    PMorph.lowThreshold = 0.000000;
    PMorph.highThreshold = 0.000000;
    PMorph.numberOfIterations = parameters.lineWidth;
    PMorph.amount = 1.00;
    PMorph.selectionPoint = 0.50;
    PMorph.structureName = "";
    PMorph.structureSize = 3;
    PMorph.structureWayTable = [ // mask
        [[
            0x00, 0x01, 0x00,
            0x01, 0x01, 0x01,
            0x00, 0x01, 0x00
        ]]
    ];

    PMorph.executeOn(maskImageView);

    Console.writeln("Mask dilated");

    /*
    PMorph.structureWayTable = [ // mask
        [[
            0x00, 0x01, 0x00,
            0x01, 0x01, 0x01,
            0x00, 0x01, 0x00
        ]]
    ];
    */

    // Create a new grayscale image with the same dimensions as the original image
    let invertedMaskWindow = new ImageWindow(selectedImage.width, selectedImage.height,
        1, // 1 channel for grayscale
        selectedImage.bitsPerSample,
        selectedImage.isReal,
        false
    );

    let invertedMaskImageView = invertedMaskWindow.mainView;
    invertedMaskImageView.beginProcess(UndoFlag_NoSwapFile);
    let invertedMaskImage = invertedMaskImageView.image;
    invertedMaskImage.fill(1); // Initialize the mask image with black (0)

    Console.writeln("Inverted mask created");

    var P = new PixelMath;
    P.expression = "" + invertedMaskImageView.id + "-" + maskImageView.id + "";
    P.expression1 = "";
    P.expression2 = "";
    P.expression3 = "";
    P.useSingleExpression = true;
    P.symbols = "";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = false;
    P.showNewImage = true;
    P.newImageId = "";
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

    P.executeOn(invertedMaskImageView);

    Console.writeln("Inverted mask inverted");

    // Create a new grayscale image with the same dimensions as the original image
    let MMTWindow = new ImageWindow(selectedImage.width, selectedImage.height,
        selectedImage.numberOfChannels, // 1 channel for grayscale
        selectedImage.bitsPerSample,
        selectedImage.isReal,
        false
    );

    let MMTImageView = MMTWindow.mainView;
    MMTImageView.beginProcess(UndoFlag_NoSwapFile);
    let MMTImage = MMTImageView.image;
    MMTImage.apply(selectedImage); // Initialize the mask image with black (0)

    Console.writeln("MMT image created");
    
    var PMMT = new MultiscaleMedianTransform;
    PMMT.layers = [ // enabled, biasEnabled, bias, noiseReductionEnabled, noiseReductionThreshold, noiseReductionAmount, noiseReductionAdaptive
        [false, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [false, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [false, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [false, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [false, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [false, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
        [true, true, 0.000, false, 1.0000, 1.00, 0.0000]
    ];
    PMMT.transform = MultiscaleMedianTransform.prototype.MultiscaleMedianTransform;
    PMMT.medianWaveletThreshold = 5.00;
    PMMT.scaleDelta = 0;
    PMMT.linearMask = false;
    PMMT.linearMaskAmpFactor = 100;
    PMMT.linearMaskSmoothness = 1.00;
    PMMT.linearMaskInverted = true;
    PMMT.linearMaskPreview = false;
    PMMT.lowRange = 0.0000;
    PMMT.highRange = 0.0000;
    PMMT.previewMode = MultiscaleMedianTransform.prototype.Disabled;
    PMMT.previewLayer = 0;
    PMMT.toLuminance = true;
    PMMT.toChrominance = true;
    PMMT.linear = false;


    PMMT.executeOn(MMTImageView);

    Console.writeln("MMT image executed");
    
    /*
    var PConv = new Convolution;
    PConv.mode = Convolution.prototype.Parametric;
    PConv.sigma = 9.00;
    PConv.shape = 6.00;
    PConv.aspectRatio = 1.00;
    PConv.rotationAngle = 0.00;
    PConv.filterSource = "";
    PConv.rescaleHighPass = false;
    PConv.viewId = "";

    PConv.executeOn(MMTImageView);
    */

    // Create a new grayscale image with the same dimensions as the original image
    /*
    let finalWindow = new ImageWindow(selectedImage.width, selectedImage.height,
        1, // 1 channel for grayscale
        selectedImage.bitsPerSample,
        selectedImage.isReal,
        false
    );

    let finalImageView = finalWindow.mainView;
    finalImageView.beginProcess(UndoFlag_NoSwapFile);
    let finalImage = finalImageView.image;
    finalImage.apply(selectedImage); // Initialize the mask image with black (0)
    */

    let selectedImageView = parameters.targetWindow.mainView;
    P.expression = "(" + invertedMaskImageView.id + "*" + selectedImageView.id + ") + (" + maskImageView.id + "*" + MMTImageView.id + ")";

    
    P.executeOn(selectedImageView);

    // PM.expression = "" + maskImageView.id + "";
    // PM.executeOn(selectedImageView);

    parameters.displayLines = false;
    this.createAndDisplayTemporaryImage(selectedImageView.image);

    MMTWindow.show();
    maskWindow.show();
    invertedMaskWindow.show();
    // finalWindow.show();

    if (!invertedMaskWindow.mainView.window.isNull) invertedMaskWindow.mainView.window.forceClose();
    if (!MMTWindow.mainView.window.isNull) MMTWindow.mainView.window.forceClose();
    if (!maskWindow.mainView.window.isNull) maskWindow.mainView.window.forceClose();













    // maskImageView.endProcess();

    // Set mask window ID based on mask type
    let maskSuffix = "";
    if (this.maskType === "Binary") {
        maskSuffix = "_bin";
    } else if (this.maskType === "Lightness") {
        maskSuffix = "_lght";
    } else if (this.maskType === "Chrominance") {
        maskSuffix = "_chrm";
    } else if (this.maskType === "Color") {
        maskSuffix = "_color";
    }

    

    maskImageView.id = parameters.targetWindow.mainView.id + "_Lines_Mask" + maskSuffix;
    maskWindow.show();

    // Apply convolution to blur the mask image
/*
var blurAmount = this.blurAmount_Slider.value;
if (blurAmount > 0) {
    var P = new Convolution;
    P.mode = Convolution.prototype.Parametric;
    P.sigma = blurAmount;
    P.executeOn(maskImageView);
} else {
    console.writeln("Skipping convolution as blurAmount is 0.");
    console.flush();
}
*/

};


function main() {
    console.show();
    // Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    // Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
    let dialog = new HaloBGoneDialog();
    dialog.execute();
}

main();
